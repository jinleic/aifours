(declare-fun orbit_103 () Bool)
(declare-fun orbit_102 () Bool)
(declare-fun orbit_101 () Bool)
(declare-fun orbit_100 () Bool)
(declare-fun orbit_99 () Bool)
(declare-fun orbit_98 () Bool)
(declare-fun orbit_97 () Bool)
(declare-fun orbit_96 () Bool)
(declare-fun orbit_95 () Bool)
(declare-fun orbit_94 () Bool)
(declare-fun orbit_93 () Bool)
(declare-fun orbit_92 () Bool)
(declare-fun orbit_91 () Bool)
(declare-fun orbit_90 () Bool)
(declare-fun orbit_89 () Bool)
(declare-fun orbit_88 () Bool)
(declare-fun orbit_87 () Bool)
(declare-fun orbit_86 () Bool)
(declare-fun orbit_85 () Bool)
(declare-fun orbit_84 () Bool)
(declare-fun orbit_83 () Bool)
(declare-fun orbit_82 () Bool)
(declare-fun orbit_81 () Bool)
(declare-fun orbit_80 () Bool)
(declare-fun orbit_79 () Bool)
(declare-fun orbit_78 () Bool)
(declare-fun orbit_77 () Bool)
(declare-fun orbit_76 () Bool)
(declare-fun orbit_75 () Bool)
(declare-fun orbit_74 () Bool)
(declare-fun orbit_73 () Bool)
(declare-fun orbit_72 () Bool)
(declare-fun orbit_71 () Bool)
(declare-fun orbit_70 () Bool)
(declare-fun orbit_69 () Bool)
(declare-fun orbit_68 () Bool)
(declare-fun orbit_67 () Bool)
(declare-fun orbit_66 () Bool)
(declare-fun orbit_65 () Bool)
(declare-fun orbit_64 () Bool)
(declare-fun orbit_63 () Bool)
(declare-fun orbit_62 () Bool)
(declare-fun orbit_61 () Bool)
(declare-fun orbit_60 () Bool)
(declare-fun orbit_59 () Bool)
(declare-fun orbit_58 () Bool)
(declare-fun orbit_57 () Bool)
(declare-fun orbit_56 () Bool)
(declare-fun orbit_55 () Bool)
(declare-fun orbit_54 () Bool)
(declare-fun orbit_53 () Bool)
(declare-fun orbit_52 () Bool)
(declare-fun orbit_51 () Bool)
(declare-fun orbit_50 () Bool)
(declare-fun orbit_49 () Bool)
(declare-fun orbit_48 () Bool)
(declare-fun orbit_47 () Bool)
(declare-fun orbit_46 () Bool)
(declare-fun orbit_45 () Bool)
(declare-fun orbit_44 () Bool)
(declare-fun orbit_43 () Bool)
(declare-fun orbit_42 () Bool)
(declare-fun orbit_41 () Bool)
(declare-fun orbit_40 () Bool)
(declare-fun orbit_39 () Bool)
(declare-fun orbit_38 () Bool)
(declare-fun orbit_37 () Bool)
(declare-fun orbit_36 () Bool)
(declare-fun orbit_35 () Bool)
(declare-fun orbit_34 () Bool)
(declare-fun orbit_33 () Bool)
(declare-fun orbit_32 () Bool)
(declare-fun orbit_31 () Bool)
(declare-fun orbit_30 () Bool)
(declare-fun orbit_29 () Bool)
(declare-fun orbit_28 () Bool)
(declare-fun orbit_27 () Bool)
(declare-fun orbit_26 () Bool)
(declare-fun orbit_25 () Bool)
(declare-fun orbit_24 () Bool)
(declare-fun orbit_23 () Bool)
(declare-fun orbit_22 () Bool)
(declare-fun orbit_21 () Bool)
(declare-fun orbit_20 () Bool)
(declare-fun orbit_19 () Bool)
(declare-fun orbit_18 () Bool)
(declare-fun orbit_17 () Bool)
(declare-fun orbit_16 () Bool)
(declare-fun orbit_15 () Bool)
(declare-fun orbit_14 () Bool)
(declare-fun orbit_13 () Bool)
(declare-fun orbit_12 () Bool)
(declare-fun orbit_11 () Bool)
(declare-fun orbit_10 () Bool)
(declare-fun orbit_9 () Bool)
(declare-fun orbit_8 () Bool)
(declare-fun orbit_7 () Bool)
(declare-fun orbit_6 () Bool)
(declare-fun orbit_5 () Bool)
(declare-fun orbit_4 () Bool)
(declare-fun orbit_3 () Bool)
(declare-fun orbit_2 () Bool)
(declare-fun orbit_1 () Bool)
(declare-fun orbit_0 () Bool)
(assert ((_ pbge
    242
    1
    6
    3
    6
    3
    3
    6
    6
    6
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    3
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    1
    6
    3
    3
    6
    6
    3
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    3
    6
    3
    3
    6
    3
    6
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  orbit_6
  orbit_7
  orbit_8
  orbit_9
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  orbit_20
  orbit_21
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  orbit_26
  orbit_27
  orbit_28
  orbit_29
  orbit_30
  orbit_31
  orbit_32
  orbit_33
  orbit_34
  orbit_35
  orbit_36
  orbit_37
  orbit_38
  orbit_39
  orbit_40
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  orbit_53
  orbit_54
  orbit_55
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  orbit_60
  orbit_61
  orbit_62
  orbit_63
  orbit_64
  orbit_65
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  orbit_89
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  orbit_94
  orbit_95
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    270
    1
    6
    3
    6
    3
    3
    6
    6
    6
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    3
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    1
    6
    3
    3
    6
    6
    3
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    3
    6
    3
    3
    6
    3
    6
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  orbit_6
  orbit_7
  orbit_8
  orbit_9
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  orbit_20
  orbit_21
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  orbit_26
  orbit_27
  orbit_28
  orbit_29
  orbit_30
  orbit_31
  orbit_32
  orbit_33
  orbit_34
  orbit_35
  orbit_36
  orbit_37
  orbit_38
  orbit_39
  orbit_40
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  orbit_53
  orbit_54
  orbit_55
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  orbit_60
  orbit_61
  orbit_62
  orbit_63
  orbit_64
  orbit_65
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  orbit_89
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  orbit_94
  orbit_95
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    66
    1
    4
    3
    4
    1
    1
    2
    4
    2
    1
    2
    4
    3
    4
    2
    4
    2
    2
    2
    1
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    4
    2
    4
    2
    2
    2
    2
    1
    4
    2
    4
    1
    4
    1
    1
    2
    1
    1
    2
    1
    1
    2
    2
    4
    1
    4
    1
    1
    4
    1
    4
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  orbit_6
  orbit_7
  orbit_8
  orbit_9
  orbit_11
  orbit_13
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  orbit_20
  orbit_22
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  orbit_45
  orbit_47
  (not orbit_50)
  (not orbit_52)
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  orbit_80
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    94
    1
    4
    3
    4
    1
    1
    2
    4
    2
    1
    2
    4
    3
    4
    2
    4
    2
    2
    2
    1
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    4
    2
    4
    2
    2
    2
    2
    1
    4
    2
    4
    1
    4
    1
    1
    2
    1
    1
    2
    1
    1
    2
    2
    4
    1
    4
    1
    1
    4
    1
    4
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  orbit_6
  orbit_7
  orbit_8
  orbit_9
  orbit_11
  orbit_13
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  orbit_20
  orbit_22
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  orbit_45
  orbit_47
  (not orbit_50)
  (not orbit_52)
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  orbit_80
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    6
    1
    2
    3
    1
    6
    2
    2
    3
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    6
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    6
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    3
    6
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    6
    1
    3
    6
    2
    3
    6
    2
    1
    2
    3
    6
    3
    2
    2
    6
    6
    2
    1
    2
    1
    3
    2
    3
    6
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  orbit_6
  orbit_7
  orbit_8
  orbit_9
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  orbit_24
  orbit_25
  orbit_26
  orbit_27
  orbit_28
  orbit_29
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  orbit_37
  orbit_38
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  orbit_55
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  orbit_60
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    142
    1
    6
    1
    2
    3
    1
    6
    2
    2
    3
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    6
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    6
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    3
    6
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    6
    1
    3
    6
    2
    3
    6
    2
    1
    2
    3
    6
    3
    2
    2
    6
    6
    2
    1
    2
    1
    3
    2
    3
    6
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  orbit_6
  orbit_7
  orbit_8
  orbit_9
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  orbit_24
  orbit_25
  orbit_26
  orbit_27
  orbit_28
  orbit_29
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  orbit_37
  orbit_38
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  orbit_55
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  orbit_60
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    4
    1
    4
    1
    3
    2
    2
    1
    2
    4
    1
    2
    2
    2
    2
    1
    4
    1
    2
    4
    1
    2
    1
    4
    3
    2
    2
    2
    4
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    4
    2
    2
    2
    2
    2
    1
    2
    4
    1
    4
    3
    1
    2
    4
    1
    4
    3
    2
    1
    1
    2
    2
    4
    1
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  orbit_6
  orbit_8
  orbit_9
  orbit_11
  orbit_12
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  orbit_20
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  orbit_27
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  orbit_33
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_63)
  (not orbit_65)
  orbit_67
  orbit_69
  orbit_70
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_87
  (not orbit_89)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_98
  orbit_99
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    4
    1
    4
    1
    3
    2
    2
    1
    2
    4
    1
    2
    2
    2
    2
    1
    4
    1
    2
    4
    1
    2
    1
    4
    3
    2
    2
    2
    4
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    4
    2
    2
    2
    2
    2
    1
    2
    4
    1
    4
    3
    1
    2
    4
    1
    4
    3
    2
    1
    1
    2
    2
    4
    1
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  orbit_6
  orbit_8
  orbit_9
  orbit_11
  orbit_12
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  orbit_20
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  orbit_27
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  orbit_33
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_63)
  (not orbit_65)
  orbit_67
  orbit_69
  orbit_70
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_87
  (not orbit_89)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_98
  orbit_99
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    3
    2
    3
    3
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    6
    6
    2
    6
    2
    1
    6
    1
    1
    2
    2
    1
    2
    2
    2
    2
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    3
    2
    2
    1
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  orbit_13
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  orbit_28
  orbit_29
  orbit_30
  (not orbit_31)
  orbit_32
  orbit_33
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_81
  orbit_82
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    142
    1
    2
    3
    2
    3
    3
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    6
    6
    2
    6
    2
    1
    6
    1
    1
    2
    2
    1
    2
    2
    2
    2
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    3
    2
    2
    1
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  orbit_13
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  orbit_28
  orbit_29
  orbit_30
  (not orbit_31)
  orbit_32
  orbit_33
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_81
  orbit_82
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    1
    6
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    6
    6
    3
    2
    1
    2
    2
    2
    6
    3
    2
    3
    2
    1
    2
    6
    2
    6
    2
    2
    6
    6
    2
    3
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    3
    2
    2
    6
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    6
    6
    2
    6
    3
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_21
  orbit_22
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  orbit_28
  orbit_29
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  orbit_80
  (not orbit_81)
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  orbit_89
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  orbit_94
  orbit_95
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    1
    6
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    6
    6
    3
    2
    1
    2
    2
    2
    6
    3
    2
    3
    2
    1
    2
    6
    2
    6
    2
    2
    6
    6
    2
    3
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    3
    2
    2
    6
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    6
    6
    2
    6
    3
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_21
  orbit_22
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  orbit_28
  orbit_29
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  orbit_80
  (not orbit_81)
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  orbit_89
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  orbit_94
  orbit_95
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    6
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  orbit_19
  orbit_20
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  orbit_38
  (not orbit_39)
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  orbit_47
  orbit_48
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  orbit_88
  orbit_89
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    110
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    6
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  orbit_19
  orbit_20
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  orbit_38
  (not orbit_39)
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  orbit_47
  orbit_48
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  orbit_88
  orbit_89
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    66
    1
    4
    1
    1
    1
    2
    4
    2
    1
    2
    1
    4
    2
    2
    2
    2
    1
    1
    2
    4
    1
    2
    3
    4
    1
    2
    2
    2
    2
    3
    4
    2
    2
    4
    2
    4
    2
    1
    4
    1
    3
    2
    1
    4
    2
    4
    2
    4
    2
    2
    2
    1
    2
    1
    4
    1
    1
    2
    1
    4
    1
    2
    1
    1
    2
    2
    1
    3
    1
    4
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_4
  (not orbit_5)
  orbit_6
  orbit_7
  orbit_8
  orbit_9
  orbit_11
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_24
  (not orbit_25)
  (not orbit_27)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_42)
  orbit_43
  orbit_44
  orbit_45
  orbit_47
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_67)
  (not orbit_69)
  orbit_70
  orbit_72
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_80)
  orbit_82
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_95
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    4
    1
    1
    1
    2
    4
    2
    1
    2
    1
    4
    2
    2
    2
    2
    1
    1
    2
    4
    1
    2
    3
    4
    1
    2
    2
    2
    2
    3
    4
    2
    2
    4
    2
    4
    2
    1
    4
    1
    3
    2
    1
    4
    2
    4
    2
    4
    2
    2
    2
    1
    2
    1
    4
    1
    1
    2
    1
    4
    1
    2
    1
    1
    2
    2
    1
    3
    1
    4
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_4
  (not orbit_5)
  orbit_6
  orbit_7
  orbit_8
  orbit_9
  orbit_11
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_24
  (not orbit_25)
  (not orbit_27)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_42)
  orbit_43
  orbit_44
  orbit_45
  orbit_47
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_67)
  (not orbit_69)
  orbit_70
  orbit_72
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_80)
  orbit_82
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_95
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    2
    2
    6
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  orbit_5
  orbit_6
  orbit_7
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_21
  orbit_22
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  orbit_38
  orbit_39
  orbit_40
  (not orbit_41)
  orbit_42
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_66)
  orbit_67
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  orbit_80
  orbit_81
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    2
    2
    6
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  orbit_5
  orbit_6
  orbit_7
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_21
  orbit_22
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  orbit_38
  orbit_39
  orbit_40
  (not orbit_41)
  orbit_42
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_66)
  orbit_67
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  orbit_80
  orbit_81
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    2
    3
    2
    1
    1
    2
    2
    2
    3
    2
    6
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    6
    6
    6
    1
    2
    1
    6
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    6
    2
    6
    2
    6
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    1
    2
    1
    1
    2
    2
    3
    2
    6
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    3
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  orbit_9
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  orbit_22
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  orbit_60
  orbit_61
  orbit_62
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  orbit_80
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    142
    1
    2
    3
    2
    1
    1
    2
    2
    2
    3
    2
    6
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    6
    6
    6
    1
    2
    1
    6
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    6
    2
    6
    2
    6
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    1
    2
    1
    1
    2
    2
    3
    2
    6
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    3
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  orbit_9
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  orbit_22
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  orbit_60
  orbit_61
  orbit_62
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  orbit_80
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    50
    1
    3
    1
    1
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    3
    6
    1
    2
    3
    1
    2
    2
    2
    2
    3
    6
    2
    2
    2
    1
    3
    3
    2
    1
    2
    2
    6
    6
    2
    1
    2
    1
    1
    1
    2
    1
    1
    2
    3
    1
    2
    2
    1
    3
    3
    1
    1
    3
    3
    1)
  orbit_0
  orbit_2
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  orbit_14
  orbit_16
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  (not orbit_24)
  (not orbit_25)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  (not orbit_43)
  (not orbit_45)
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  orbit_55
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_63
  orbit_65
  orbit_67
  orbit_69
  (not orbit_70)
  (not orbit_72)
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_80
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_95
  orbit_96
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    78
    1
    3
    1
    1
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    3
    6
    1
    2
    3
    1
    2
    2
    2
    2
    3
    6
    2
    2
    2
    1
    3
    3
    2
    1
    2
    2
    6
    6
    2
    1
    2
    1
    1
    1
    2
    1
    1
    2
    3
    1
    2
    2
    1
    3
    3
    1
    1
    3
    3
    1)
  orbit_0
  orbit_2
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  orbit_14
  orbit_16
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  (not orbit_24)
  (not orbit_25)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  (not orbit_43)
  (not orbit_45)
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  orbit_55
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_63
  orbit_65
  orbit_67
  orbit_69
  (not orbit_70)
  (not orbit_72)
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_80
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_95
  orbit_96
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    6
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  orbit_9
  orbit_10
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  orbit_20
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  (not orbit_44)
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  orbit_49
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  orbit_60
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  orbit_70
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  orbit_89
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    6
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  orbit_9
  orbit_10
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  orbit_20
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  (not orbit_44)
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  orbit_49
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  orbit_60
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  orbit_70
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  orbit_89
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    1
    4
    1
    1
    2
    2
    1
    2
    4
    1
    2
    4
    2
    2
    2
    1
    3
    2
    4
    1
    2
    1
    4
    1
    2
    2
    2
    4
    2
    1
    4
    2
    2
    4
    2
    4
    2
    1
    4
    3
    1
    2
    1
    2
    2
    4
    2
    2
    2
    1
    4
    2
    4
    1
    1
    1
    2
    1
    4
    1
    2
    3
    1
    2
    2
    4
    1
    4
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  (not orbit_13)
  (not orbit_14)
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_22
  (not orbit_24)
  (not orbit_25)
  (not orbit_27)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_47)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  orbit_54
  orbit_55
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_61)
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_80)
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  orbit_87
  (not orbit_89)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    1
    4
    1
    1
    2
    2
    1
    2
    4
    1
    2
    4
    2
    2
    2
    1
    3
    2
    4
    1
    2
    1
    4
    1
    2
    2
    2
    4
    2
    1
    4
    2
    2
    4
    2
    4
    2
    1
    4
    3
    1
    2
    1
    2
    2
    4
    2
    2
    2
    1
    4
    2
    4
    1
    1
    1
    2
    1
    4
    1
    2
    3
    1
    2
    2
    4
    1
    4
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  (not orbit_13)
  (not orbit_14)
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_22
  (not orbit_24)
  (not orbit_25)
  (not orbit_27)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_47)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  orbit_54
  orbit_55
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_61)
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_80)
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  orbit_87
  (not orbit_89)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    66
    1
    4
    1
    1
    1
    2
    2
    1
    2
    4
    4
    1
    2
    4
    2
    2
    2
    3
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    4
    2
    4
    2
    3
    4
    1
    1
    4
    2
    1
    4
    2
    2
    4
    2
    2
    2
    3
    4
    2
    1
    4
    1
    1
    2
    4
    1
    1
    2
    1
    1
    2
    2
    3
    4
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_42
  (not orbit_43)
  (not orbit_45)
  (not orbit_47)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_67
  orbit_69
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  orbit_89
  orbit_91
  orbit_93
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_98
  orbit_99
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    4
    1
    1
    1
    2
    2
    1
    2
    4
    4
    1
    2
    4
    2
    2
    2
    3
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    4
    2
    4
    2
    3
    4
    1
    1
    4
    2
    1
    4
    2
    2
    4
    2
    2
    2
    3
    4
    2
    1
    4
    1
    1
    2
    4
    1
    1
    2
    1
    1
    2
    2
    3
    4
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_42
  (not orbit_43)
  (not orbit_45)
  (not orbit_47)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_67
  orbit_69
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  orbit_89
  orbit_91
  orbit_93
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_98
  orbit_99
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    114
    1
    6
    1
    2
    3
    1
    6
    2
    2
    3
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    6
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    6
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    3
    6
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    6
    1
    3
    6
    2
    3
    6
    2
    1
    2
    3
    6
    3
    2
    2
    6
    6
    2
    1
    2
    1
    3
    2
    3
    6
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  (not orbit_25)
  orbit_26
  (not orbit_27)
  (not orbit_28)
  orbit_29
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  orbit_37
  orbit_38
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  orbit_55
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_60
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  (not orbit_89)
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    142
    1
    6
    1
    2
    3
    1
    6
    2
    2
    3
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    6
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    6
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    3
    6
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    6
    1
    3
    6
    2
    3
    6
    2
    1
    2
    3
    6
    3
    2
    2
    6
    6
    2
    1
    2
    1
    3
    2
    3
    6
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  (not orbit_25)
  orbit_26
  (not orbit_27)
  (not orbit_28)
  orbit_29
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  orbit_37
  orbit_38
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  orbit_55
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_60
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  (not orbit_89)
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    66
    1
    4
    1
    1
    1
    2
    4
    2
    1
    2
    1
    4
    2
    2
    2
    2
    1
    1
    2
    4
    1
    2
    3
    4
    1
    2
    2
    2
    2
    3
    4
    2
    2
    4
    2
    4
    2
    1
    4
    1
    3
    2
    1
    4
    2
    4
    2
    4
    2
    2
    2
    1
    2
    1
    4
    1
    1
    2
    1
    4
    1
    2
    1
    1
    2
    2
    1
    3
    1
    4
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_4
  orbit_5
  orbit_6
  (not orbit_7)
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_24
  orbit_25
  orbit_27
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_47
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  orbit_72
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  orbit_80
  orbit_82
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_95
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    4
    1
    1
    1
    2
    4
    2
    1
    2
    1
    4
    2
    2
    2
    2
    1
    1
    2
    4
    1
    2
    3
    4
    1
    2
    2
    2
    2
    3
    4
    2
    2
    4
    2
    4
    2
    1
    4
    1
    3
    2
    1
    4
    2
    4
    2
    4
    2
    2
    2
    1
    2
    1
    4
    1
    1
    2
    1
    4
    1
    2
    1
    1
    2
    2
    1
    3
    1
    4
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_4
  orbit_5
  orbit_6
  (not orbit_7)
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_24
  orbit_25
  orbit_27
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_47
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  orbit_72
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  orbit_80
  orbit_82
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_95
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  (not orbit_28)
  orbit_29
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  (not orbit_28)
  orbit_29
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    4
    1
    1
    1
    2
    2
    1
    2
    4
    4
    1
    2
    4
    2
    2
    2
    3
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    4
    2
    4
    2
    3
    4
    1
    1
    4
    2
    1
    4
    2
    2
    4
    2
    2
    2
    3
    4
    2
    1
    4
    1
    1
    2
    4
    1
    1
    2
    1
    1
    2
    2
    3
    4
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_4
  orbit_5
  orbit_6
  orbit_8
  orbit_9
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_42
  orbit_43
  (not orbit_45)
  (not orbit_47)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_63
  orbit_64
  orbit_65
  orbit_67
  orbit_69
  orbit_70
  orbit_71
  (not orbit_72)
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  orbit_89
  (not orbit_91)
  orbit_93
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  (not orbit_99)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    4
    1
    1
    1
    2
    2
    1
    2
    4
    4
    1
    2
    4
    2
    2
    2
    3
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    4
    2
    4
    2
    3
    4
    1
    1
    4
    2
    1
    4
    2
    2
    4
    2
    2
    2
    3
    4
    2
    1
    4
    1
    1
    2
    4
    1
    1
    2
    1
    1
    2
    2
    3
    4
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_4
  orbit_5
  orbit_6
  orbit_8
  orbit_9
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_42
  orbit_43
  (not orbit_45)
  (not orbit_47)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_63
  orbit_64
  orbit_65
  orbit_67
  orbit_69
  orbit_70
  orbit_71
  (not orbit_72)
  orbit_74
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  orbit_89
  (not orbit_91)
  orbit_93
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  (not orbit_99)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  orbit_28
  orbit_29
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  orbit_63
  orbit_64
  orbit_65
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  orbit_28
  orbit_29
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  orbit_63
  orbit_64
  orbit_65
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    2
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_7)
  orbit_8
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  orbit_38
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  orbit_47
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_62)
  orbit_63
  orbit_64
  orbit_65
  (not orbit_66)
  (not orbit_67)
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  orbit_72
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  orbit_95
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    2
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_7)
  orbit_8
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  orbit_38
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  orbit_47
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_62)
  orbit_63
  orbit_64
  orbit_65
  (not orbit_66)
  (not orbit_67)
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  orbit_72
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  orbit_95
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    3
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  orbit_20
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  orbit_33
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  orbit_38
  orbit_39
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_66
  orbit_67
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  (not orbit_77)
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  orbit_88
  orbit_89
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    3
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  orbit_20
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  orbit_33
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  orbit_38
  orbit_39
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_66
  orbit_67
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  (not orbit_77)
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  orbit_88
  orbit_89
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    50
    1
    1
    1
    3
    2
    2
    1
    2
    1
    2
    2
    6
    2
    3
    3
    2
    1
    2
    1
    3
    2
    2
    2
    2
    1
    2
    6
    6
    2
    3
    3
    1
    2
    1
    2
    2
    2
    2
    6
    3
    2
    1
    3
    1
    2
    1
    3
    2
    3
    1
    2
    2
    3
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_22)
  (not orbit_24)
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_33
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  orbit_47
  orbit_50
  orbit_52
  orbit_53
  orbit_55
  orbit_56
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  (not orbit_72)
  (not orbit_74)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_80)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_87
  orbit_89
  (not orbit_91)
  orbit_93
  (not orbit_95)
  (not orbit_96)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    78
    1
    1
    1
    3
    2
    2
    1
    2
    1
    2
    2
    6
    2
    3
    3
    2
    1
    2
    1
    3
    2
    2
    2
    2
    1
    2
    6
    6
    2
    3
    3
    1
    2
    1
    2
    2
    2
    2
    6
    3
    2
    1
    3
    1
    2
    1
    3
    2
    3
    1
    2
    2
    3
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_22)
  (not orbit_24)
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_33
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  orbit_47
  orbit_50
  orbit_52
  orbit_53
  orbit_55
  orbit_56
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  (not orbit_72)
  (not orbit_74)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_80)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_87
  orbit_89
  (not orbit_91)
  orbit_93
  (not orbit_95)
  (not orbit_96)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    1
    2
    1
    3
    2
    2
    6
    3
    2
    2
    2
    6
    1
    2
    2
    6
    2
    2
    2
    6
    1
    2
    1
    2
    6
    2
    2
    1
    2
    3
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    3
    2
    6
    3
    2
    2
    2
    2
    2
    2
    6
    2
    6
    2
    1
    6
    2
    2
    1
    2
    3
    1
    2
    2
    3
    2
    2
    3
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    6
    3
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  orbit_9
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  orbit_33
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  orbit_95
  (not orbit_96)
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    142
    1
    2
    1
    2
    1
    3
    2
    2
    6
    3
    2
    2
    2
    6
    1
    2
    2
    6
    2
    2
    2
    6
    1
    2
    1
    2
    6
    2
    2
    1
    2
    3
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    3
    2
    6
    3
    2
    2
    2
    2
    2
    2
    6
    2
    6
    2
    1
    6
    2
    2
    1
    2
    3
    1
    2
    2
    3
    2
    2
    3
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    6
    3
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  orbit_9
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  orbit_33
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  orbit_95
  (not orbit_96)
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    66
    1
    1
    4
    1
    1
    2
    2
    1
    2
    4
    1
    2
    4
    2
    2
    2
    1
    3
    2
    4
    1
    2
    1
    4
    1
    2
    2
    2
    4
    2
    1
    4
    2
    2
    4
    2
    4
    2
    1
    4
    3
    1
    2
    1
    2
    2
    4
    2
    2
    2
    1
    4
    2
    4
    1
    1
    1
    2
    1
    4
    1
    2
    3
    1
    2
    2
    4
    1
    4
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  (not orbit_13)
  (not orbit_14)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_22
  (not orbit_24)
  orbit_25
  (not orbit_27)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  orbit_45
  (not orbit_47)
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  orbit_54
  orbit_55
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_80
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_87)
  (not orbit_89)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    1
    4
    1
    1
    2
    2
    1
    2
    4
    1
    2
    4
    2
    2
    2
    1
    3
    2
    4
    1
    2
    1
    4
    1
    2
    2
    2
    4
    2
    1
    4
    2
    2
    4
    2
    4
    2
    1
    4
    3
    1
    2
    1
    2
    2
    4
    2
    2
    2
    1
    4
    2
    4
    1
    1
    1
    2
    1
    4
    1
    2
    3
    1
    2
    2
    4
    1
    4
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  (not orbit_13)
  (not orbit_14)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_22
  (not orbit_24)
  orbit_25
  (not orbit_27)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  orbit_45
  (not orbit_47)
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  orbit_54
  orbit_55
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_80
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_87)
  (not orbit_89)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    2
    2
    6
    1
    6
    3
    6
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    2
    6
    2
    2
    2
    2
    1
    2
    3
    3
    6
    2
    1
    2
    2
    2
    2
    2
    6
    2
    6
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    6
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    3
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  orbit_25
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  (not orbit_47)
  (not orbit_48)
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  orbit_55
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  orbit_67
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  orbit_95
  orbit_96
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    142
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    2
    2
    6
    1
    6
    3
    6
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    2
    6
    2
    2
    2
    2
    1
    2
    3
    3
    6
    2
    1
    2
    2
    2
    2
    2
    6
    2
    6
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    6
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    3
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  orbit_25
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  (not orbit_47)
  (not orbit_48)
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  orbit_55
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  orbit_67
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  orbit_95
  orbit_96
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  orbit_19
  orbit_20
  (not orbit_21)
  (not orbit_22)
  orbit_23
  orbit_24
  orbit_25
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  orbit_50
  (not orbit_51)
  orbit_52
  orbit_53
  orbit_54
  orbit_55
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_62)
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  orbit_71
  orbit_72
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  orbit_81
  (not orbit_82)
  orbit_83
  orbit_84
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  orbit_89
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  orbit_19
  orbit_20
  (not orbit_21)
  (not orbit_22)
  orbit_23
  orbit_24
  orbit_25
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  orbit_50
  (not orbit_51)
  orbit_52
  orbit_53
  orbit_54
  orbit_55
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_62)
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  orbit_71
  orbit_72
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  orbit_81
  (not orbit_82)
  orbit_83
  orbit_84
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  orbit_89
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    50
    1
    3
    1
    1
    2
    2
    3
    6
    3
    2
    2
    2
    2
    3
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    3
    1
    1
    2
    3
    6
    6
    2
    2
    2
    3
    6
    1
    1
    1
    2
    3
    1
    2
    1
    1
    2
    2
    3
    1
    1
    3
    1
    3
    3
    1)
  orbit_0
  orbit_2
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_8)
  (not orbit_9)
  (not orbit_11)
  orbit_14
  orbit_16
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_22)
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  (not orbit_47)
  orbit_50
  orbit_52
  (not orbit_53)
  (not orbit_55)
  (not orbit_56)
  orbit_58
  orbit_59
  orbit_61
  (not orbit_63)
  (not orbit_65)
  (not orbit_67)
  orbit_69
  orbit_70
  orbit_72
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  (not orbit_80)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_87)
  orbit_89
  orbit_91
  orbit_93
  (not orbit_95)
  (not orbit_96)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    78
    1
    3
    1
    1
    2
    2
    3
    6
    3
    2
    2
    2
    2
    3
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    3
    1
    1
    2
    3
    6
    6
    2
    2
    2
    3
    6
    1
    1
    1
    2
    3
    1
    2
    1
    1
    2
    2
    3
    1
    1
    3
    1
    3
    3
    1)
  orbit_0
  orbit_2
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_8)
  (not orbit_9)
  (not orbit_11)
  orbit_14
  orbit_16
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_22)
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  (not orbit_47)
  orbit_50
  orbit_52
  (not orbit_53)
  (not orbit_55)
  (not orbit_56)
  orbit_58
  orbit_59
  orbit_61
  (not orbit_63)
  (not orbit_65)
  (not orbit_67)
  orbit_69
  orbit_70
  orbit_72
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  (not orbit_80)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_87)
  orbit_89
  orbit_91
  orbit_93
  (not orbit_95)
  (not orbit_96)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    1
    4
    1
    1
    2
    4
    2
    3
    2
    4
    1
    4
    2
    2
    2
    2
    1
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    4
    2
    4
    2
    1
    4
    1
    1
    4
    2
    3
    2
    4
    2
    4
    2
    2
    2
    1
    2
    4
    1
    1
    1
    2
    4
    3
    1
    2
    1
    1
    2
    2
    4
    1
    1
    1
    4
    3
    1
    1
    1
    1)
  orbit_0
  orbit_2
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  (not orbit_11)
  (not orbit_12)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_45)
  orbit_47
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  orbit_59
  orbit_61
  orbit_62
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_67
  (not orbit_69)
  orbit_70
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  orbit_79
  orbit_80
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  (not orbit_89)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    1
    4
    1
    1
    2
    4
    2
    3
    2
    4
    1
    4
    2
    2
    2
    2
    1
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    4
    2
    4
    2
    1
    4
    1
    1
    4
    2
    3
    2
    4
    2
    4
    2
    2
    2
    1
    2
    4
    1
    1
    1
    2
    4
    3
    1
    2
    1
    1
    2
    2
    4
    1
    1
    1
    4
    3
    1
    1
    1
    1)
  orbit_0
  orbit_2
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  (not orbit_11)
  (not orbit_12)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_45)
  orbit_47
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  orbit_59
  orbit_61
  orbit_62
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_67
  (not orbit_69)
  orbit_70
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  orbit_79
  orbit_80
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  (not orbit_89)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    50
    1
    1
    1
    3
    2
    6
    3
    2
    1
    2
    2
    2
    2
    1
    1
    2
    1
    2
    3
    3
    2
    2
    2
    6
    3
    2
    2
    2
    6
    1
    1
    3
    6
    3
    2
    2
    2
    2
    2
    1
    2
    1
    3
    1
    2
    3
    3
    2
    1
    1
    2
    2
    1
    3
    1
    3
    1
    1
    1
    1)
  orbit_0
  orbit_2
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_8)
  (not orbit_9)
  (not orbit_11)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_33
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_42
  orbit_43
  orbit_45
  (not orbit_47)
  (not orbit_50)
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  (not orbit_56)
  orbit_58
  orbit_59
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_72)
  (not orbit_74)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_80
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_87
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_95
  orbit_96
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    78
    1
    1
    1
    3
    2
    6
    3
    2
    1
    2
    2
    2
    2
    1
    1
    2
    1
    2
    3
    3
    2
    2
    2
    6
    3
    2
    2
    2
    6
    1
    1
    3
    6
    3
    2
    2
    2
    2
    2
    1
    2
    1
    3
    1
    2
    3
    3
    2
    1
    1
    2
    2
    1
    3
    1
    3
    1
    1
    1
    1)
  orbit_0
  orbit_2
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_8)
  (not orbit_9)
  (not orbit_11)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_33
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_42
  orbit_43
  orbit_45
  (not orbit_47)
  (not orbit_50)
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  (not orbit_56)
  orbit_58
  orbit_59
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_72)
  (not orbit_74)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_80
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_87
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_95
  orbit_96
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    3
    2
    3
    3
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    6
    6
    2
    6
    2
    1
    6
    1
    1
    2
    2
    1
    2
    2
    2
    2
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    3
    2
    2
    1
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  orbit_29
  orbit_30
  (not orbit_31)
  (not orbit_32)
  orbit_33
  orbit_34
  (not orbit_35)
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  orbit_83
  orbit_84
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    142
    1
    2
    3
    2
    3
    3
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    6
    6
    2
    6
    2
    1
    6
    1
    1
    2
    2
    1
    2
    2
    2
    2
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    3
    2
    2
    1
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  orbit_29
  orbit_30
  (not orbit_31)
  (not orbit_32)
  orbit_33
  orbit_34
  (not orbit_35)
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  orbit_83
  orbit_84
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  orbit_28
  orbit_29
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  orbit_63
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  orbit_28
  orbit_29
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  orbit_63
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    2
    1
    2
    1
    3
    2
    6
    2
    1
    6
    2
    2
    2
    1
    6
    2
    2
    2
    6
    2
    2
    3
    2
    3
    2
    2
    2
    6
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    6
    6
    2
    2
    6
    2
    2
    3
    2
    3
    1
    2
    2
    1
    2
    2
    6
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    6
    2
    3
    2
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    3
    6
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  orbit_33
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  (not orbit_46)
  orbit_47
  orbit_48
  orbit_49
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  orbit_54
  orbit_55
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    142
    1
    2
    1
    2
    1
    3
    2
    6
    2
    1
    6
    2
    2
    2
    1
    6
    2
    2
    2
    6
    2
    2
    3
    2
    3
    2
    2
    2
    6
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    6
    6
    2
    2
    6
    2
    2
    3
    2
    3
    1
    2
    2
    1
    2
    2
    6
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    6
    2
    3
    2
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    3
    6
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  orbit_33
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  (not orbit_46)
  orbit_47
  orbit_48
  orbit_49
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  orbit_54
  orbit_55
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    66
    1
    1
    4
    1
    1
    2
    4
    2
    3
    2
    4
    1
    4
    2
    2
    2
    2
    1
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    4
    2
    4
    2
    1
    4
    1
    1
    4
    2
    3
    2
    4
    2
    4
    2
    2
    2
    1
    2
    4
    1
    1
    1
    2
    4
    3
    1
    2
    1
    1
    2
    2
    4
    1
    1
    1
    4
    3
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  orbit_11
  (not orbit_12)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_45)
  orbit_47
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  orbit_59
  (not orbit_61)
  orbit_62
  orbit_63
  orbit_64
  orbit_65
  orbit_67
  (not orbit_69)
  (not orbit_70)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  (not orbit_89)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    1
    4
    1
    1
    2
    4
    2
    3
    2
    4
    1
    4
    2
    2
    2
    2
    1
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    4
    2
    4
    2
    1
    4
    1
    1
    4
    2
    3
    2
    4
    2
    4
    2
    2
    2
    1
    2
    4
    1
    1
    1
    2
    4
    3
    1
    2
    1
    1
    2
    2
    4
    1
    1
    1
    4
    3
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  orbit_3
  orbit_4
  orbit_5
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  orbit_11
  (not orbit_12)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_45)
  orbit_47
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  orbit_59
  (not orbit_61)
  orbit_62
  orbit_63
  orbit_64
  orbit_65
  orbit_67
  (not orbit_69)
  (not orbit_70)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  (not orbit_89)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    2
    1
    6
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    6
    6
    3
    2
    1
    2
    2
    2
    6
    3
    2
    3
    2
    1
    2
    6
    2
    6
    2
    2
    6
    6
    2
    3
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    3
    2
    2
    6
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    6
    6
    2
    6
    3
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_21
  orbit_22
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  orbit_28
  orbit_29
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  orbit_89
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  (not orbit_94)
  orbit_95
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    142
    1
    2
    1
    6
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    6
    6
    3
    2
    1
    2
    2
    2
    6
    3
    2
    3
    2
    1
    2
    6
    2
    6
    2
    2
    6
    6
    2
    3
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    3
    2
    2
    6
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    6
    6
    2
    6
    3
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_21
  orbit_22
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  orbit_28
  orbit_29
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  orbit_89
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  (not orbit_94)
  orbit_95
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    114
    1
    3
    3
    3
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    3
    6
    3
    6
    3
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    3
    3
    3
    6
    3
    6
    6
    6
    6
    6
    3
    6
    1
    3
    3
    6
    3
    3
    6
    3
    3
    6
    6
    3
    3
    3
    3
    1
    3
    3
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_8
  (not orbit_9)
  (not orbit_11)
  orbit_14
  (not orbit_16)
  (not orbit_18)
  orbit_19
  orbit_20
  (not orbit_22)
  (not orbit_24)
  (not orbit_25)
  orbit_29
  orbit_30
  (not orbit_31)
  orbit_33
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_42
  (not orbit_43)
  (not orbit_45)
  orbit_47
  (not orbit_50)
  (not orbit_52)
  (not orbit_53)
  orbit_55
  orbit_56
  (not orbit_58)
  orbit_59
  orbit_61
  (not orbit_63)
  orbit_65
  orbit_67
  (not orbit_69)
  orbit_70
  orbit_72
  orbit_74
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_80)
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  (not orbit_89)
  (not orbit_91)
  orbit_93
  orbit_95
  orbit_96
  orbit_98
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    142
    1
    3
    3
    3
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    3
    6
    3
    6
    3
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    3
    3
    3
    6
    3
    6
    6
    6
    6
    6
    3
    6
    1
    3
    3
    6
    3
    3
    6
    3
    3
    6
    6
    3
    3
    3
    3
    1
    3
    3
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_8
  (not orbit_9)
  (not orbit_11)
  orbit_14
  (not orbit_16)
  (not orbit_18)
  orbit_19
  orbit_20
  (not orbit_22)
  (not orbit_24)
  (not orbit_25)
  orbit_29
  orbit_30
  (not orbit_31)
  orbit_33
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_42
  (not orbit_43)
  (not orbit_45)
  orbit_47
  (not orbit_50)
  (not orbit_52)
  (not orbit_53)
  orbit_55
  orbit_56
  (not orbit_58)
  orbit_59
  orbit_61
  (not orbit_63)
  orbit_65
  orbit_67
  (not orbit_69)
  orbit_70
  orbit_72
  orbit_74
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_80)
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  (not orbit_89)
  (not orbit_91)
  orbit_93
  orbit_95
  orbit_96
  orbit_98
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    3
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  orbit_33
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  orbit_38
  (not orbit_39)
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_66
  orbit_67
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  (not orbit_88)
  orbit_89
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    3
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  orbit_33
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  orbit_38
  (not orbit_39)
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_66
  orbit_67
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  (not orbit_88)
  orbit_89
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    50
    1
    1
    3
    1
    6
    2
    3
    2
    1
    2
    2
    2
    2
    1
    3
    2
    3
    2
    1
    1
    2
    6
    2
    2
    1
    2
    2
    2
    2
    1
    3
    1
    2
    3
    2
    2
    2
    2
    2
    1
    2
    1
    1
    3
    6
    3
    1
    2
    3
    3
    2
    6
    1
    1
    3
    3
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_8
  (not orbit_9)
  (not orbit_11)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  (not orbit_24)
  (not orbit_25)
  orbit_29
  orbit_30
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  orbit_55
  orbit_56
  (not orbit_58)
  orbit_59
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_72)
  (not orbit_74)
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_80
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_87)
  orbit_89
  orbit_91
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    78
    1
    1
    3
    1
    6
    2
    3
    2
    1
    2
    2
    2
    2
    1
    3
    2
    3
    2
    1
    1
    2
    6
    2
    2
    1
    2
    2
    2
    2
    1
    3
    1
    2
    3
    2
    2
    2
    2
    2
    1
    2
    1
    1
    3
    6
    3
    1
    2
    3
    3
    2
    6
    1
    1
    3
    3
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_8
  (not orbit_9)
  (not orbit_11)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  (not orbit_24)
  (not orbit_25)
  orbit_29
  orbit_30
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  orbit_55
  orbit_56
  (not orbit_58)
  orbit_59
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_72)
  (not orbit_74)
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_80
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_87)
  orbit_89
  orbit_91
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    50
    1
    3
    3
    3
    2
    2
    1
    2
    3
    6
    6
    2
    2
    1
    1
    2
    3
    6
    1
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    3
    2
    1
    3
    6
    1
    3
    2
    2
    1
    1
    1
    1
    1
    3
    3
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  orbit_14
  (not orbit_16)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_24
  orbit_25
  orbit_29
  orbit_30
  orbit_31
  orbit_33
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  (not orbit_55)
  (not orbit_56)
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_72)
  orbit_74
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_80
  orbit_83
  orbit_84
  orbit_85
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    78
    1
    3
    3
    3
    2
    2
    1
    2
    3
    6
    6
    2
    2
    1
    1
    2
    3
    6
    1
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    3
    2
    1
    3
    6
    1
    3
    2
    2
    1
    1
    1
    1
    1
    3
    3
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  orbit_14
  (not orbit_16)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_24
  orbit_25
  orbit_29
  orbit_30
  orbit_31
  orbit_33
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  (not orbit_55)
  (not orbit_56)
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_72)
  orbit_74
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_80
  orbit_83
  orbit_84
  orbit_85
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    6
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  orbit_6
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  orbit_38
  orbit_39
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  orbit_47
  (not orbit_48)
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  (not orbit_80)
  orbit_81
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  (not orbit_88)
  orbit_89
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    110
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    6
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  orbit_6
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  orbit_38
  orbit_39
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  orbit_47
  (not orbit_48)
  orbit_49
  orbit_50
  orbit_51
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  (not orbit_80)
  orbit_81
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  (not orbit_88)
  orbit_89
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    50
    1
    1
    3
    1
    2
    2
    1
    2
    1
    2
    2
    2
    6
    3
    1
    2
    3
    2
    3
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    3
    1
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    3
    2
    1
    1
    2
    1
    3
    6
    2
    3
    3
    1
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  orbit_20
  (not orbit_22)
  orbit_24
  (not orbit_25)
  orbit_29
  orbit_30
  (not orbit_31)
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  (not orbit_47)
  (not orbit_50)
  orbit_52
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_72)
  (not orbit_74)
  orbit_76
  orbit_77
  orbit_78
  (not orbit_80)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  orbit_93
  orbit_95
  orbit_96
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    78
    1
    1
    3
    1
    2
    2
    1
    2
    1
    2
    2
    2
    6
    3
    1
    2
    3
    2
    3
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    3
    1
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    3
    2
    1
    1
    2
    1
    3
    6
    2
    3
    3
    1
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  orbit_20
  (not orbit_22)
  orbit_24
  (not orbit_25)
  orbit_29
  orbit_30
  (not orbit_31)
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  (not orbit_47)
  (not orbit_50)
  orbit_52
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_72)
  (not orbit_74)
  orbit_76
  orbit_77
  orbit_78
  (not orbit_80)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  orbit_93
  orbit_95
  orbit_96
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    3
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  orbit_6
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  orbit_20
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  orbit_33
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  orbit_38
  orbit_39
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  orbit_63
  orbit_64
  (not orbit_65)
  (not orbit_66)
  orbit_67
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  orbit_77
  (not orbit_78)
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  orbit_88
  orbit_89
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    3
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  orbit_6
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  orbit_20
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  orbit_33
  (not orbit_34)
  (not orbit_35)
  (not orbit_36)
  orbit_37
  orbit_38
  orbit_39
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  orbit_45
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  orbit_63
  orbit_64
  (not orbit_65)
  (not orbit_66)
  orbit_67
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  orbit_77
  (not orbit_78)
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  orbit_88
  orbit_89
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    4
    1
    4
    1
    3
    2
    2
    1
    2
    4
    1
    2
    2
    2
    2
    1
    4
    1
    2
    4
    1
    2
    1
    4
    3
    2
    2
    2
    4
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    4
    2
    2
    2
    2
    2
    1
    2
    4
    1
    4
    3
    1
    2
    4
    1
    4
    3
    2
    1
    1
    2
    2
    4
    1
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_12)
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_27)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  orbit_33
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_63)
  orbit_65
  orbit_67
  orbit_69
  (not orbit_70)
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  (not orbit_99)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    4
    1
    4
    1
    3
    2
    2
    1
    2
    4
    1
    2
    2
    2
    2
    1
    4
    1
    2
    4
    1
    2
    1
    4
    3
    2
    2
    2
    4
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    4
    2
    2
    2
    2
    2
    1
    2
    4
    1
    4
    3
    1
    2
    4
    1
    4
    3
    2
    1
    1
    2
    2
    4
    1
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_12)
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_27)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  orbit_33
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_63)
  orbit_65
  orbit_67
  orbit_69
  (not orbit_70)
  orbit_72
  orbit_73
  orbit_74
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  (not orbit_99)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    2
    2
    6
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  orbit_6
  (not orbit_7)
  orbit_8
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  orbit_22
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  orbit_38
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  (not orbit_47)
  (not orbit_48)
  orbit_49
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_66)
  orbit_67
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    2
    2
    6
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  orbit_6
  (not orbit_7)
  orbit_8
  (not orbit_9)
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  orbit_22
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  orbit_38
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  (not orbit_47)
  (not orbit_48)
  orbit_49
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_66)
  orbit_67
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    1
    2
    1
    3
    2
    6
    2
    1
    6
    2
    2
    2
    1
    6
    2
    2
    2
    6
    2
    2
    3
    2
    3
    2
    2
    2
    6
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    6
    6
    2
    2
    6
    2
    2
    3
    2
    3
    1
    2
    2
    1
    2
    2
    6
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    6
    2
    3
    2
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    3
    6
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  orbit_33
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  orbit_47
  orbit_48
  (not orbit_49)
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  orbit_55
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_66)
  (not orbit_67)
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    1
    2
    1
    3
    2
    6
    2
    1
    6
    2
    2
    2
    1
    6
    2
    2
    2
    6
    2
    2
    3
    2
    3
    2
    2
    2
    6
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    6
    6
    2
    2
    6
    2
    2
    3
    2
    3
    1
    2
    2
    1
    2
    2
    6
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    6
    2
    3
    2
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    3
    6
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  orbit_33
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  orbit_47
  orbit_48
  (not orbit_49)
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  orbit_55
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_66)
  (not orbit_67)
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  orbit_81
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    1
    4
    1
    1
    2
    4
    2
    3
    2
    4
    1
    4
    2
    2
    2
    2
    1
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    4
    2
    4
    2
    1
    4
    1
    1
    4
    2
    3
    2
    4
    2
    4
    2
    2
    2
    1
    2
    4
    1
    1
    1
    2
    4
    3
    1
    2
    1
    1
    2
    2
    4
    1
    1
    1
    4
    3
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_11)
  orbit_12
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  (not orbit_45)
  orbit_47
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_61
  (not orbit_62)
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_67
  (not orbit_69)
  orbit_70
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  (not orbit_89)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    1
    4
    1
    1
    2
    4
    2
    3
    2
    4
    1
    4
    2
    2
    2
    2
    1
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    4
    2
    4
    2
    1
    4
    1
    1
    4
    2
    3
    2
    4
    2
    4
    2
    2
    2
    1
    2
    4
    1
    1
    1
    2
    4
    3
    1
    2
    1
    1
    2
    2
    4
    1
    1
    1
    4
    3
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_11)
  orbit_12
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  (not orbit_45)
  orbit_47
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_61
  (not orbit_62)
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_67
  (not orbit_69)
  orbit_70
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  (not orbit_89)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_21
  (not orbit_22)
  orbit_23
  orbit_24
  (not orbit_25)
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  orbit_52
  (not orbit_53)
  (not orbit_54)
  orbit_55
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_62
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  orbit_72
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  orbit_84
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  orbit_89
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_21
  (not orbit_22)
  orbit_23
  orbit_24
  (not orbit_25)
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  orbit_52
  (not orbit_53)
  (not orbit_54)
  orbit_55
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_62
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  orbit_72
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  orbit_84
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  orbit_89
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    50
    1
    1
    1
    3
    2
    6
    3
    2
    1
    2
    2
    2
    2
    1
    1
    2
    1
    2
    3
    3
    2
    2
    2
    6
    3
    2
    2
    2
    6
    1
    1
    3
    6
    3
    2
    2
    2
    2
    2
    1
    2
    1
    3
    1
    2
    3
    3
    2
    1
    1
    2
    2
    1
    3
    1
    3
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_8
  (not orbit_9)
  orbit_11
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_33
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_42
  (not orbit_43)
  orbit_45
  (not orbit_47)
  orbit_50
  (not orbit_52)
  orbit_53
  (not orbit_55)
  orbit_56
  (not orbit_58)
  orbit_59
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_72)
  orbit_74
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_80)
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_87)
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_95
  (not orbit_96)
  orbit_98
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    78
    1
    1
    1
    3
    2
    6
    3
    2
    1
    2
    2
    2
    2
    1
    1
    2
    1
    2
    3
    3
    2
    2
    2
    6
    3
    2
    2
    2
    6
    1
    1
    3
    6
    3
    2
    2
    2
    2
    2
    1
    2
    1
    3
    1
    2
    3
    3
    2
    1
    1
    2
    2
    1
    3
    1
    3
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_8
  (not orbit_9)
  orbit_11
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_33
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_42
  (not orbit_43)
  orbit_45
  (not orbit_47)
  orbit_50
  (not orbit_52)
  orbit_53
  (not orbit_55)
  orbit_56
  (not orbit_58)
  orbit_59
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_72)
  orbit_74
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_80)
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_87)
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_95
  (not orbit_96)
  orbit_98
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    2
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_7
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  orbit_38
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  orbit_47
  (not orbit_48)
  orbit_49
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_62
  orbit_63
  orbit_64
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  orbit_72
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  orbit_95
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    2
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_7
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  orbit_38
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  orbit_47
  (not orbit_48)
  orbit_49
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_62
  orbit_63
  orbit_64
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  orbit_72
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  orbit_95
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    50
    1
    1
    3
    1
    6
    2
    3
    2
    1
    2
    2
    2
    2
    1
    3
    2
    3
    2
    1
    1
    2
    6
    2
    2
    1
    2
    2
    2
    2
    1
    3
    1
    2
    3
    2
    2
    2
    2
    2
    1
    2
    1
    1
    3
    6
    3
    1
    2
    3
    3
    2
    6
    1
    1
    3
    3
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_8)
  (not orbit_9)
  orbit_11
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  (not orbit_24)
  orbit_25
  orbit_29
  (not orbit_30)
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  orbit_55
  (not orbit_56)
  orbit_58
  orbit_59
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_72)
  orbit_74
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_80)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_87
  orbit_89
  (not orbit_91)
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_98
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    78
    1
    1
    3
    1
    6
    2
    3
    2
    1
    2
    2
    2
    2
    1
    3
    2
    3
    2
    1
    1
    2
    6
    2
    2
    1
    2
    2
    2
    2
    1
    3
    1
    2
    3
    2
    2
    2
    2
    2
    1
    2
    1
    1
    3
    6
    3
    1
    2
    3
    3
    2
    6
    1
    1
    3
    3
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_8)
  (not orbit_9)
  orbit_11
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  (not orbit_24)
  orbit_25
  orbit_29
  (not orbit_30)
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  orbit_55
  (not orbit_56)
  orbit_58
  orbit_59
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_72)
  orbit_74
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_80)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_87
  orbit_89
  (not orbit_91)
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_98
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    1
    3
    1
    2
    4
    2
    1
    2
    4
    4
    1
    4
    2
    4
    2
    2
    2
    1
    4
    1
    2
    4
    3
    2
    1
    4
    1
    2
    2
    2
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    2
    4
    2
    2
    2
    2
    1
    4
    2
    1
    1
    3
    2
    4
    1
    4
    1
    2
    1
    3
    2
    2
    1
    4
    1
    1
    4
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  orbit_9
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  orbit_27
  orbit_29
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_42
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  orbit_47
  orbit_50
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_65)
  orbit_67
  (not orbit_69)
  orbit_70
  orbit_71
  orbit_72
  (not orbit_74)
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    1
    3
    1
    2
    4
    2
    1
    2
    4
    4
    1
    4
    2
    4
    2
    2
    2
    1
    4
    1
    2
    4
    3
    2
    1
    4
    1
    2
    2
    2
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    2
    4
    2
    2
    2
    2
    1
    4
    2
    1
    1
    3
    2
    4
    1
    4
    1
    2
    1
    3
    2
    2
    1
    4
    1
    1
    4
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  orbit_9
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  orbit_27
  orbit_29
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_42
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  orbit_47
  orbit_50
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_65)
  orbit_67
  (not orbit_69)
  orbit_70
  orbit_71
  orbit_72
  (not orbit_74)
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    2
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  orbit_5
  orbit_6
  orbit_7
  orbit_8
  (not orbit_9)
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  orbit_38
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  orbit_47
  orbit_48
  orbit_49
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_66
  (not orbit_67)
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  orbit_72
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  orbit_95
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    2
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  orbit_5
  orbit_6
  orbit_7
  orbit_8
  (not orbit_9)
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  orbit_38
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  orbit_47
  orbit_48
  orbit_49
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_66
  (not orbit_67)
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  orbit_72
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  orbit_95
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    1
    3
    1
    2
    4
    2
    1
    2
    4
    4
    1
    4
    2
    4
    2
    2
    2
    1
    4
    1
    2
    4
    3
    2
    1
    4
    1
    2
    2
    2
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    2
    4
    2
    2
    2
    2
    1
    4
    2
    1
    1
    3
    2
    4
    1
    4
    1
    2
    1
    3
    2
    2
    1
    4
    1
    1
    4
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  orbit_9
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  orbit_27
  orbit_29
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_42
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_47
  (not orbit_50)
  (not orbit_52)
  orbit_53
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_65
  orbit_67
  (not orbit_69)
  (not orbit_70)
  orbit_71
  orbit_72
  orbit_74
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  orbit_80
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    1
    3
    1
    2
    4
    2
    1
    2
    4
    4
    1
    4
    2
    4
    2
    2
    2
    1
    4
    1
    2
    4
    3
    2
    1
    4
    1
    2
    2
    2
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    2
    4
    2
    2
    2
    2
    1
    4
    2
    1
    1
    3
    2
    4
    1
    4
    1
    2
    1
    3
    2
    2
    1
    4
    1
    1
    4
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  orbit_9
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  orbit_27
  orbit_29
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_42
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_47
  (not orbit_50)
  (not orbit_52)
  orbit_53
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_65
  orbit_67
  (not orbit_69)
  (not orbit_70)
  orbit_71
  orbit_72
  orbit_74
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  orbit_80
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    2
    2
    6
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_7
  orbit_8
  (not orbit_9)
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_21
  orbit_22
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  orbit_38
  orbit_39
  (not orbit_40)
  orbit_41
  orbit_42
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  (not orbit_47)
  orbit_48
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_64)
  orbit_65
  orbit_66
  orbit_67
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_81
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    2
    2
    6
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  (not orbit_5)
  orbit_6
  orbit_7
  orbit_8
  (not orbit_9)
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_21
  orbit_22
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  orbit_38
  orbit_39
  (not orbit_40)
  orbit_41
  orbit_42
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  (not orbit_47)
  orbit_48
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_64)
  orbit_65
  orbit_66
  orbit_67
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_81
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    1
    2
    1
    3
    2
    2
    6
    3
    2
    2
    2
    6
    1
    2
    2
    6
    2
    2
    2
    6
    1
    2
    1
    2
    6
    2
    2
    1
    2
    3
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    3
    2
    6
    3
    2
    2
    2
    2
    2
    2
    6
    2
    6
    2
    1
    6
    2
    2
    1
    2
    3
    1
    2
    2
    3
    2
    2
    3
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    6
    3
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  orbit_33
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  orbit_95
  orbit_96
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    1
    2
    1
    3
    2
    2
    6
    3
    2
    2
    2
    6
    1
    2
    2
    6
    2
    2
    2
    6
    1
    2
    1
    2
    6
    2
    2
    1
    2
    3
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    3
    2
    6
    3
    2
    2
    2
    2
    2
    2
    6
    2
    6
    2
    1
    6
    2
    2
    1
    2
    3
    1
    2
    2
    3
    2
    2
    3
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    6
    3
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  orbit_33
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  orbit_95
  orbit_96
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    1
    3
    1
    2
    4
    2
    1
    2
    4
    4
    1
    4
    2
    4
    2
    2
    2
    1
    4
    1
    2
    4
    3
    2
    1
    4
    1
    2
    2
    2
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    2
    4
    2
    2
    2
    2
    1
    4
    2
    1
    1
    3
    2
    4
    1
    4
    1
    2
    1
    3
    2
    2
    1
    4
    1
    1
    4
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  (not orbit_27)
  orbit_29
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_42
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_47
  orbit_50
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_65)
  orbit_67
  (not orbit_69)
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_74)
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    1
    3
    1
    2
    4
    2
    1
    2
    4
    4
    1
    4
    2
    4
    2
    2
    2
    1
    4
    1
    2
    4
    3
    2
    1
    4
    1
    2
    2
    2
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    2
    4
    2
    2
    2
    2
    1
    4
    2
    1
    1
    3
    2
    4
    1
    4
    1
    2
    1
    3
    2
    2
    1
    4
    1
    1
    4
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_23
  orbit_24
  orbit_25
  (not orbit_27)
  orbit_29
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  orbit_42
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_47
  orbit_50
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_65)
  orbit_67
  (not orbit_69)
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_74)
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    2
    2
    6
    1
    6
    3
    6
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    2
    6
    2
    2
    2
    2
    1
    2
    3
    3
    6
    2
    1
    2
    2
    2
    2
    2
    6
    2
    6
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    6
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    3
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  orbit_24
  orbit_25
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  (not orbit_47)
  orbit_48
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  orbit_55
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  orbit_67
  orbit_68
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  orbit_95
  orbit_96
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    142
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    2
    2
    6
    1
    6
    3
    6
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    2
    6
    2
    2
    2
    2
    1
    2
    3
    3
    6
    2
    1
    2
    2
    2
    2
    2
    6
    2
    6
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    6
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    3
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  orbit_24
  orbit_25
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  (not orbit_47)
  orbit_48
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  orbit_55
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  orbit_67
  orbit_68
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  orbit_95
  orbit_96
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    1
    2
    1
    3
    2
    6
    2
    1
    6
    2
    2
    2
    1
    6
    2
    2
    2
    6
    2
    2
    3
    2
    3
    2
    2
    2
    6
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    6
    6
    2
    2
    6
    2
    2
    3
    2
    3
    1
    2
    2
    1
    2
    2
    6
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    6
    2
    3
    2
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    3
    6
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  orbit_33
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  orbit_46
  orbit_47
  (not orbit_48)
  orbit_49
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  orbit_54
  orbit_55
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  orbit_66
  (not orbit_67)
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    1
    2
    1
    3
    2
    6
    2
    1
    6
    2
    2
    2
    1
    6
    2
    2
    2
    6
    2
    2
    3
    2
    3
    2
    2
    2
    6
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    6
    6
    2
    2
    6
    2
    2
    3
    2
    3
    1
    2
    2
    1
    2
    2
    6
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    6
    2
    3
    2
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    3
    6
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  orbit_33
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  orbit_46
  orbit_47
  (not orbit_48)
  orbit_49
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  orbit_54
  orbit_55
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  orbit_66
  (not orbit_67)
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    1
    4
    1
    1
    2
    2
    1
    2
    4
    1
    2
    4
    2
    2
    2
    1
    3
    2
    4
    1
    2
    1
    4
    1
    2
    2
    2
    4
    2
    1
    4
    2
    2
    4
    2
    4
    2
    1
    4
    3
    1
    2
    1
    2
    2
    4
    2
    2
    2
    1
    4
    2
    4
    1
    1
    1
    2
    1
    4
    1
    2
    3
    1
    2
    2
    4
    1
    4
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  orbit_13
  (not orbit_14)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_22
  (not orbit_24)
  (not orbit_25)
  orbit_27
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  orbit_45
  (not orbit_47)
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  orbit_55
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_61)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_80)
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  orbit_87
  (not orbit_89)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    1
    4
    1
    1
    2
    2
    1
    2
    4
    1
    2
    4
    2
    2
    2
    1
    3
    2
    4
    1
    2
    1
    4
    1
    2
    2
    2
    4
    2
    1
    4
    2
    2
    4
    2
    4
    2
    1
    4
    3
    1
    2
    1
    2
    2
    4
    2
    2
    2
    1
    4
    2
    4
    1
    1
    1
    2
    1
    4
    1
    2
    3
    1
    2
    2
    4
    1
    4
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  orbit_2
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  orbit_13
  (not orbit_14)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_22
  (not orbit_24)
  (not orbit_25)
  orbit_27
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  orbit_45
  (not orbit_47)
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  orbit_55
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_61)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_80)
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  orbit_87
  (not orbit_89)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_98
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    2
    2
    6
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_21)
  orbit_22
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  orbit_38
  (not orbit_39)
  orbit_40
  orbit_41
  orbit_42
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  (not orbit_47)
  orbit_48
  orbit_49
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  orbit_66
  orbit_67
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  orbit_80
  (not orbit_81)
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    2
    2
    6
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_21)
  orbit_22
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  orbit_37
  orbit_38
  (not orbit_39)
  orbit_40
  orbit_41
  orbit_42
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  (not orbit_47)
  orbit_48
  orbit_49
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  orbit_66
  orbit_67
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  orbit_80
  (not orbit_81)
  orbit_82
  orbit_83
  orbit_84
  orbit_85
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    2
    3
    2
    1
    1
    2
    2
    2
    3
    2
    6
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    6
    6
    6
    1
    2
    1
    6
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    6
    2
    6
    2
    6
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    1
    2
    1
    1
    2
    2
    3
    2
    6
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    3
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  orbit_9
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  orbit_22
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  (not orbit_60)
  orbit_61
  (not orbit_62)
  orbit_63
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  orbit_80
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    142
    1
    2
    3
    2
    1
    1
    2
    2
    2
    3
    2
    6
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    6
    6
    6
    1
    2
    1
    6
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    6
    2
    6
    2
    6
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    1
    2
    1
    1
    2
    2
    3
    2
    6
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    3
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  orbit_9
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_21)
  orbit_22
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  (not orbit_60)
  orbit_61
  (not orbit_62)
  orbit_63
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  orbit_80
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    66
    1
    4
    3
    4
    1
    1
    2
    4
    2
    1
    2
    4
    3
    4
    2
    4
    2
    2
    2
    1
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    4
    2
    4
    2
    2
    2
    2
    1
    4
    2
    4
    1
    4
    1
    1
    2
    1
    1
    2
    1
    1
    2
    2
    4
    1
    4
    1
    1
    4
    1
    4
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  orbit_6
  (not orbit_7)
  orbit_8
  orbit_9
  orbit_11
  (not orbit_13)
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  orbit_20
  orbit_22
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  orbit_45
  orbit_47
  (not orbit_50)
  (not orbit_52)
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  orbit_80
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    94
    1
    4
    3
    4
    1
    1
    2
    4
    2
    1
    2
    4
    3
    4
    2
    4
    2
    2
    2
    1
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    4
    2
    4
    2
    2
    2
    2
    1
    4
    2
    4
    1
    4
    1
    1
    2
    1
    1
    2
    1
    1
    2
    2
    4
    1
    4
    1
    1
    4
    1
    4
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  orbit_6
  (not orbit_7)
  orbit_8
  orbit_9
  orbit_11
  (not orbit_13)
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  orbit_20
  orbit_22
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  orbit_45
  orbit_47
  (not orbit_50)
  (not orbit_52)
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  orbit_80
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  (not orbit_100)
  (not orbit_101)
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    6
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_10)
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  orbit_44
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_60)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  orbit_70
  orbit_71
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  (not orbit_80)
  orbit_81
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  orbit_89
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    6
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_10)
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_21
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  orbit_44
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_60)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  orbit_70
  orbit_71
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  (not orbit_80)
  orbit_81
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  orbit_89
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    4
    1
    1
    1
    2
    4
    2
    1
    2
    1
    4
    2
    2
    2
    2
    1
    1
    2
    4
    1
    2
    3
    4
    1
    2
    2
    2
    2
    3
    4
    2
    2
    4
    2
    4
    2
    1
    4
    1
    3
    2
    1
    4
    2
    4
    2
    4
    2
    2
    2
    1
    2
    1
    4
    1
    1
    2
    1
    4
    1
    2
    1
    1
    2
    2
    1
    3
    1
    4
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_7)
  orbit_8
  orbit_9
  orbit_11
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_24
  (not orbit_25)
  orbit_27
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_42)
  orbit_43
  (not orbit_44)
  orbit_45
  orbit_47
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_67)
  (not orbit_69)
  orbit_70
  orbit_72
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_80)
  (not orbit_82)
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_95
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    4
    1
    1
    1
    2
    4
    2
    1
    2
    1
    4
    2
    2
    2
    2
    1
    1
    2
    4
    1
    2
    3
    4
    1
    2
    2
    2
    2
    3
    4
    2
    2
    4
    2
    4
    2
    1
    4
    1
    3
    2
    1
    4
    2
    4
    2
    4
    2
    2
    2
    1
    2
    1
    4
    1
    1
    2
    1
    4
    1
    2
    1
    1
    2
    2
    1
    3
    1
    4
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_7)
  orbit_8
  orbit_9
  orbit_11
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_22
  orbit_24
  (not orbit_25)
  orbit_27
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  (not orbit_42)
  orbit_43
  (not orbit_44)
  orbit_45
  orbit_47
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_67)
  (not orbit_69)
  orbit_70
  orbit_72
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_80)
  (not orbit_82)
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  orbit_95
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    6
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_10
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  orbit_20
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  orbit_44
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  (not orbit_49)
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_60
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  (not orbit_70)
  orbit_71
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  orbit_80
  orbit_81
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  orbit_89
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    6
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_10
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  orbit_20
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  orbit_44
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  (not orbit_49)
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_60
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  (not orbit_70)
  orbit_71
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  orbit_80
  orbit_81
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  orbit_89
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    66
    1
    1
    3
    1
    2
    4
    2
    1
    2
    4
    4
    1
    4
    2
    4
    2
    2
    2
    1
    4
    1
    2
    4
    3
    2
    1
    4
    1
    2
    2
    2
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    2
    4
    2
    2
    2
    2
    1
    4
    2
    1
    1
    3
    2
    4
    1
    4
    1
    2
    1
    3
    2
    2
    1
    4
    1
    1
    4
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_27)
  orbit_29
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_42
  orbit_43
  orbit_44
  (not orbit_45)
  orbit_47
  (not orbit_50)
  (not orbit_52)
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_65
  orbit_67
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_74
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  orbit_80
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    1
    3
    1
    2
    4
    2
    1
    2
    4
    4
    1
    4
    2
    4
    2
    2
    2
    1
    4
    1
    2
    4
    3
    2
    1
    4
    1
    2
    2
    2
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    2
    4
    2
    2
    2
    2
    1
    4
    2
    1
    1
    3
    2
    4
    1
    4
    1
    2
    1
    3
    2
    2
    1
    4
    1
    1
    4
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_27)
  orbit_29
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_35)
  orbit_38
  orbit_40
  orbit_42
  orbit_43
  orbit_44
  (not orbit_45)
  orbit_47
  (not orbit_50)
  (not orbit_52)
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_65
  orbit_67
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_74
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  orbit_80
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_87
  orbit_89
  orbit_91
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  orbit_19
  orbit_20
  orbit_21
  (not orbit_22)
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  orbit_50
  orbit_51
  orbit_52
  orbit_53
  (not orbit_54)
  orbit_55
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_62
  orbit_63
  orbit_64
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  (not orbit_71)
  orbit_72
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_81)
  orbit_82
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  orbit_89
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  orbit_18
  orbit_19
  orbit_20
  orbit_21
  (not orbit_22)
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  orbit_50
  orbit_51
  orbit_52
  orbit_53
  (not orbit_54)
  orbit_55
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_62
  orbit_63
  orbit_64
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  (not orbit_71)
  orbit_72
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_81)
  orbit_82
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  orbit_89
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    50
    1
    1
    3
    1
    2
    2
    1
    2
    1
    2
    2
    2
    6
    3
    1
    2
    3
    2
    3
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    3
    1
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    3
    2
    1
    1
    2
    1
    3
    6
    2
    3
    3
    1
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  orbit_20
  (not orbit_22)
  orbit_24
  orbit_25
  orbit_29
  (not orbit_30)
  (not orbit_31)
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  (not orbit_47)
  orbit_50
  orbit_52
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_72)
  orbit_74
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_80
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_87
  (not orbit_89)
  orbit_91
  orbit_93
  orbit_95
  (not orbit_96)
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    78
    1
    1
    3
    1
    2
    2
    1
    2
    1
    2
    2
    2
    6
    3
    1
    2
    3
    2
    3
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    3
    1
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    3
    2
    1
    1
    2
    1
    3
    6
    2
    3
    3
    1
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  orbit_20
  (not orbit_22)
  orbit_24
  orbit_25
  orbit_29
  (not orbit_30)
  (not orbit_31)
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  (not orbit_47)
  orbit_50
  orbit_52
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_72)
  orbit_74
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_80
  (not orbit_83)
  (not orbit_84)
  orbit_85
  orbit_87
  (not orbit_89)
  orbit_91
  orbit_93
  orbit_95
  (not orbit_96)
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  (not orbit_19)
  orbit_20
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  (not orbit_50)
  orbit_51
  orbit_52
  (not orbit_53)
  orbit_54
  orbit_55
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_62)
  orbit_63
  orbit_64
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  orbit_71
  orbit_72
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_81
  orbit_82
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  orbit_89
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  (not orbit_19)
  orbit_20
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_26)
  orbit_27
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  (not orbit_50)
  orbit_51
  orbit_52
  (not orbit_53)
  orbit_54
  orbit_55
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_62)
  orbit_63
  orbit_64
  (not orbit_65)
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  orbit_71
  orbit_72
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_81
  orbit_82
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  orbit_89
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    50
    1
    1
    1
    3
    2
    2
    1
    2
    1
    2
    2
    6
    2
    3
    3
    2
    1
    2
    1
    3
    2
    2
    2
    2
    1
    2
    6
    6
    2
    3
    3
    1
    2
    1
    2
    2
    2
    2
    6
    3
    2
    1
    3
    1
    2
    1
    3
    2
    3
    1
    2
    2
    3
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  (not orbit_14)
  orbit_16
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_22)
  (not orbit_24)
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_33
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  orbit_47
  (not orbit_50)
  orbit_52
  (not orbit_53)
  orbit_55
  (not orbit_56)
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  orbit_70
  (not orbit_72)
  orbit_74
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_80
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  orbit_89
  orbit_91
  orbit_93
  (not orbit_95)
  orbit_96
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    78
    1
    1
    1
    3
    2
    2
    1
    2
    1
    2
    2
    6
    2
    3
    3
    2
    1
    2
    1
    3
    2
    2
    2
    2
    1
    2
    6
    6
    2
    3
    3
    1
    2
    1
    2
    2
    2
    2
    6
    3
    2
    1
    3
    1
    2
    1
    3
    2
    3
    1
    2
    2
    3
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_8)
  orbit_9
  orbit_11
  (not orbit_14)
  orbit_16
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_22)
  (not orbit_24)
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  orbit_33
  (not orbit_35)
  orbit_38
  orbit_40
  (not orbit_42)
  orbit_43
  orbit_45
  orbit_47
  (not orbit_50)
  orbit_52
  (not orbit_53)
  orbit_55
  (not orbit_56)
  orbit_58
  (not orbit_59)
  (not orbit_61)
  orbit_63
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  orbit_70
  (not orbit_72)
  orbit_74
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_80
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_87)
  orbit_89
  orbit_91
  orbit_93
  (not orbit_95)
  orbit_96
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    2
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  (not orbit_5)
  orbit_6
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  orbit_38
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  orbit_47
  orbit_48
  (not orbit_49)
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_62)
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_66
  (not orbit_67)
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  orbit_72
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  orbit_95
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    2
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  (not orbit_5)
  orbit_6
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  orbit_10
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  orbit_38
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  orbit_47
  orbit_48
  (not orbit_49)
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  orbit_61
  (not orbit_62)
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_66
  (not orbit_67)
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  orbit_72
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  orbit_78
  orbit_79
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  orbit_95
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    1
    2
    1
    3
    2
    2
    6
    3
    2
    2
    2
    6
    1
    2
    2
    6
    2
    2
    2
    6
    1
    2
    1
    2
    6
    2
    2
    1
    2
    3
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    3
    2
    6
    3
    2
    2
    2
    2
    2
    2
    6
    2
    6
    2
    1
    6
    2
    2
    1
    2
    3
    1
    2
    2
    3
    2
    2
    3
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    6
    3
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  orbit_33
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  orbit_95
  orbit_96
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    1
    2
    1
    3
    2
    2
    6
    3
    2
    2
    2
    6
    1
    2
    2
    6
    2
    2
    2
    6
    1
    2
    1
    2
    6
    2
    2
    1
    2
    3
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    3
    2
    6
    3
    2
    2
    2
    2
    2
    2
    6
    2
    6
    2
    1
    6
    2
    2
    1
    2
    3
    1
    2
    2
    3
    2
    2
    3
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    6
    3
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  (not orbit_14)
  (not orbit_15)
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  orbit_33
  orbit_34
  orbit_35
  orbit_36
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  orbit_95
  orbit_96
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    4
    1
    1
    1
    2
    2
    1
    2
    4
    4
    1
    2
    4
    2
    2
    2
    3
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    4
    2
    4
    2
    3
    4
    1
    1
    4
    2
    1
    4
    2
    2
    4
    2
    2
    2
    3
    4
    2
    1
    4
    1
    1
    2
    4
    1
    1
    2
    1
    1
    2
    2
    3
    4
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_8)
  orbit_9
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_22)
  orbit_23
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_42
  (not orbit_43)
  (not orbit_45)
  (not orbit_47)
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_67
  orbit_69
  (not orbit_70)
  orbit_71
  (not orbit_72)
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  orbit_89
  orbit_91
  orbit_93
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_98
  (not orbit_99)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    4
    1
    1
    1
    2
    2
    1
    2
    4
    4
    1
    2
    4
    2
    2
    2
    3
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    4
    2
    4
    2
    3
    4
    1
    1
    4
    2
    1
    4
    2
    2
    4
    2
    2
    2
    3
    4
    2
    1
    4
    1
    1
    2
    4
    1
    1
    2
    1
    1
    2
    2
    3
    4
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_8)
  orbit_9
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_22)
  orbit_23
  orbit_24
  orbit_25
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_33)
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_42
  (not orbit_43)
  (not orbit_45)
  (not orbit_47)
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  orbit_63
  (not orbit_64)
  (not orbit_65)
  orbit_67
  orbit_69
  (not orbit_70)
  orbit_71
  (not orbit_72)
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_83
  orbit_84
  (not orbit_85)
  orbit_87
  orbit_89
  orbit_91
  orbit_93
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_98
  (not orbit_99)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    1
    2
    2
    2
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    6
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_10)
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  orbit_20
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  orbit_49
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  (not orbit_60)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  orbit_80
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  orbit_89
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    1
    2
    2
    2
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    6
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    3
    2
    2
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_10)
  (not orbit_11)
  orbit_12
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  orbit_20
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  orbit_49
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  (not orbit_60)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  (not orbit_70)
  (not orbit_71)
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  orbit_80
  (not orbit_81)
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  orbit_89
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    66
    1
    4
    1
    4
    1
    3
    2
    2
    1
    2
    4
    1
    2
    2
    2
    2
    1
    4
    1
    2
    4
    1
    2
    1
    4
    3
    2
    2
    2
    4
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    4
    2
    2
    2
    2
    2
    1
    2
    4
    1
    4
    3
    1
    2
    4
    1
    4
    3
    2
    1
    1
    2
    2
    4
    1
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_8)
  orbit_9
  (not orbit_11)
  orbit_12
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  orbit_27
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  orbit_33
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_63)
  orbit_65
  orbit_67
  orbit_69
  (not orbit_70)
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  orbit_99
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    4
    1
    4
    1
    3
    2
    2
    1
    2
    4
    1
    2
    2
    2
    2
    1
    4
    1
    2
    4
    1
    2
    1
    4
    3
    2
    2
    2
    4
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    4
    2
    2
    2
    2
    2
    1
    2
    4
    1
    4
    3
    1
    2
    4
    1
    4
    3
    2
    1
    1
    2
    2
    4
    1
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_8)
  orbit_9
  (not orbit_11)
  orbit_12
  (not orbit_14)
  orbit_16
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  orbit_27
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  orbit_33
  orbit_35
  (not orbit_38)
  (not orbit_40)
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  (not orbit_47)
  orbit_50
  orbit_52
  orbit_53
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_63)
  orbit_65
  orbit_67
  orbit_69
  (not orbit_70)
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_87)
  (not orbit_89)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  orbit_99
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    242
    1
    6
    3
    6
    3
    3
    6
    6
    6
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    3
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    1
    6
    3
    3
    6
    6
    3
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    3
    6
    3
    3
    6
    3
    6
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  orbit_20
  (not orbit_21)
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  orbit_26
  (not orbit_27)
  (not orbit_28)
  orbit_29
  (not orbit_30)
  orbit_31
  orbit_32
  orbit_33
  orbit_34
  (not orbit_35)
  (not orbit_36)
  orbit_37
  orbit_38
  (not orbit_39)
  (not orbit_40)
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  (not orbit_53)
  (not orbit_54)
  orbit_55
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_60
  (not orbit_61)
  (not orbit_62)
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  orbit_89
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  orbit_94
  orbit_95
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    270
    1
    6
    3
    6
    3
    3
    6
    6
    6
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    3
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    1
    6
    3
    3
    6
    6
    3
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    3
    6
    3
    3
    6
    3
    6
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_7)
  (not orbit_8)
  orbit_9
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  orbit_20
  (not orbit_21)
  orbit_22
  orbit_23
  orbit_24
  (not orbit_25)
  orbit_26
  (not orbit_27)
  (not orbit_28)
  orbit_29
  (not orbit_30)
  orbit_31
  orbit_32
  orbit_33
  orbit_34
  (not orbit_35)
  (not orbit_36)
  orbit_37
  orbit_38
  (not orbit_39)
  (not orbit_40)
  orbit_41
  orbit_42
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  orbit_47
  orbit_48
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  (not orbit_53)
  (not orbit_54)
  orbit_55
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  orbit_59
  orbit_60
  (not orbit_61)
  (not orbit_62)
  orbit_63
  orbit_64
  (not orbit_65)
  orbit_66
  orbit_67
  orbit_68
  orbit_69
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_86)
  (not orbit_87)
  (not orbit_88)
  orbit_89
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  orbit_94
  orbit_95
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    4
    3
    4
    1
    1
    2
    4
    2
    1
    2
    4
    3
    4
    2
    4
    2
    2
    2
    1
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    4
    2
    4
    2
    2
    2
    2
    1
    4
    2
    4
    1
    4
    1
    1
    2
    1
    1
    2
    1
    1
    2
    2
    4
    1
    4
    1
    1
    4
    1
    4
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_7)
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_13)
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_22
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  orbit_45
  orbit_47
  orbit_50
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  orbit_63
  orbit_65
  (not orbit_67)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_80)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_87
  (not orbit_89)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    94
    1
    4
    3
    4
    1
    1
    2
    4
    2
    1
    2
    4
    3
    4
    2
    4
    2
    2
    2
    1
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    4
    2
    4
    2
    2
    2
    2
    1
    4
    2
    4
    1
    4
    1
    1
    2
    1
    1
    2
    1
    1
    2
    2
    4
    1
    4
    1
    1
    4
    1
    4
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  orbit_6
  (not orbit_7)
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_13)
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_22
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_41
  orbit_42
  (not orbit_43)
  orbit_45
  orbit_47
  orbit_50
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  orbit_63
  orbit_65
  (not orbit_67)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_80)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_87
  (not orbit_89)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    1
    6
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    6
    6
    3
    2
    1
    2
    2
    2
    6
    3
    2
    3
    2
    1
    2
    6
    2
    6
    2
    2
    6
    6
    2
    3
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    3
    2
    2
    6
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    6
    6
    2
    6
    3
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  orbit_20
  (not orbit_21)
  orbit_22
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  (not orbit_28)
  orbit_29
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_81
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  orbit_89
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  orbit_94
  orbit_95
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    142
    1
    2
    1
    6
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    6
    6
    3
    2
    1
    2
    2
    2
    6
    3
    2
    3
    2
    1
    2
    6
    2
    6
    2
    2
    6
    6
    2
    3
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    3
    2
    2
    6
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    6
    6
    2
    6
    3
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  orbit_20
  (not orbit_21)
  orbit_22
  orbit_23
  (not orbit_24)
  (not orbit_25)
  orbit_26
  orbit_27
  (not orbit_28)
  orbit_29
  (not orbit_30)
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  orbit_74
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_81
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  orbit_89
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  orbit_94
  orbit_95
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    3
    2
    3
    3
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    6
    6
    2
    6
    2
    1
    6
    1
    1
    2
    2
    1
    2
    2
    2
    2
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    3
    2
    2
    1
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  (not orbit_13)
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  (not orbit_28)
  orbit_29
  (not orbit_30)
  (not orbit_31)
  orbit_32
  orbit_33
  (not orbit_34)
  orbit_35
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  orbit_78
  orbit_79
  orbit_80
  (not orbit_81)
  orbit_82
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    3
    2
    3
    3
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    6
    6
    2
    6
    2
    1
    6
    1
    1
    2
    2
    1
    2
    2
    2
    2
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    3
    2
    2
    1
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  (not orbit_13)
  orbit_14
  orbit_15
  (not orbit_16)
  orbit_17
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  (not orbit_28)
  orbit_29
  (not orbit_30)
  (not orbit_31)
  orbit_32
  orbit_33
  (not orbit_34)
  orbit_35
  orbit_36
  (not orbit_37)
  (not orbit_38)
  orbit_39
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  orbit_76
  (not orbit_77)
  orbit_78
  orbit_79
  orbit_80
  (not orbit_81)
  orbit_82
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    6
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  orbit_38
  orbit_39
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  orbit_47
  orbit_48
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  orbit_80
  orbit_81
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  (not orbit_88)
  orbit_89
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    6
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_7)
  (not orbit_8)
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  orbit_38
  orbit_39
  (not orbit_40)
  orbit_41
  orbit_42
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  orbit_47
  orbit_48
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  (not orbit_79)
  orbit_80
  orbit_81
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  (not orbit_88)
  orbit_89
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    1
    4
    1
    1
    2
    2
    1
    2
    4
    1
    2
    4
    2
    2
    2
    1
    3
    2
    4
    1
    2
    1
    4
    1
    2
    2
    2
    4
    2
    1
    4
    2
    2
    4
    2
    4
    2
    1
    4
    3
    1
    2
    1
    2
    2
    4
    2
    2
    2
    1
    4
    2
    4
    1
    1
    1
    2
    1
    4
    1
    2
    3
    1
    2
    2
    4
    1
    4
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  orbit_13
  (not orbit_14)
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_22
  (not orbit_24)
  orbit_25
  orbit_27
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_47)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  (not orbit_54)
  orbit_55
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_80
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_87)
  (not orbit_89)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    1
    4
    1
    1
    2
    2
    1
    2
    4
    1
    2
    4
    2
    2
    2
    1
    3
    2
    4
    1
    2
    1
    4
    1
    2
    2
    2
    4
    2
    1
    4
    2
    2
    4
    2
    4
    2
    1
    4
    3
    1
    2
    1
    2
    2
    4
    2
    2
    2
    1
    4
    2
    4
    1
    1
    1
    2
    1
    4
    1
    2
    3
    1
    2
    2
    4
    1
    4
    1
    3
    1
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  orbit_13
  (not orbit_14)
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_22
  (not orbit_24)
  orbit_25
  orbit_27
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_47)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  (not orbit_54)
  orbit_55
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_67)
  orbit_69
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_80
  orbit_82
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_87)
  (not orbit_89)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_98)
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    2
    3
    2
    1
    1
    2
    2
    2
    3
    2
    6
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    6
    6
    6
    1
    2
    1
    6
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    6
    2
    6
    2
    6
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    1
    2
    1
    1
    2
    2
    3
    2
    6
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    3
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  orbit_9
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  orbit_22
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  orbit_60
  (not orbit_61)
  (not orbit_62)
  orbit_63
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    3
    2
    1
    1
    2
    2
    2
    3
    2
    6
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    6
    6
    6
    1
    2
    1
    6
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    6
    2
    6
    2
    6
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    1
    2
    1
    1
    2
    2
    3
    2
    6
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    3
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  orbit_9
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  orbit_22
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_32)
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  orbit_60
  (not orbit_61)
  (not orbit_62)
  orbit_63
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  (not orbit_71)
  orbit_72
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  (not orbit_80)
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    50
    1
    3
    1
    1
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    3
    6
    1
    2
    3
    1
    2
    2
    2
    2
    3
    6
    2
    2
    2
    1
    3
    3
    2
    1
    2
    2
    6
    6
    2
    1
    2
    1
    1
    1
    2
    1
    1
    2
    3
    1
    2
    2
    1
    3
    3
    1
    1
    3
    3
    1)
  orbit_0
  (not orbit_2)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  orbit_14
  (not orbit_16)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  (not orbit_24)
  orbit_25
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  orbit_43
  (not orbit_45)
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  orbit_55
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_63
  (not orbit_65)
  orbit_67
  orbit_69
  orbit_70
  (not orbit_72)
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_80)
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_87
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_95
  (not orbit_96)
  orbit_98
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    78
    1
    3
    1
    1
    2
    2
    1
    2
    3
    2
    2
    2
    2
    1
    3
    6
    1
    2
    3
    1
    2
    2
    2
    2
    3
    6
    2
    2
    2
    1
    3
    3
    2
    1
    2
    2
    6
    6
    2
    1
    2
    1
    1
    1
    2
    1
    1
    2
    3
    1
    2
    2
    1
    3
    3
    1
    1
    3
    3
    1)
  orbit_0
  (not orbit_2)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  orbit_14
  (not orbit_16)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_22
  (not orbit_24)
  orbit_25
  (not orbit_29)
  orbit_30
  (not orbit_31)
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  orbit_43
  (not orbit_45)
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  orbit_55
  (not orbit_56)
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_63
  (not orbit_65)
  orbit_67
  orbit_69
  orbit_70
  (not orbit_72)
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_80)
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_87
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_95
  (not orbit_96)
  orbit_98
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    66
    1
    1
    4
    1
    1
    2
    4
    2
    3
    2
    4
    1
    4
    2
    2
    2
    2
    1
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    4
    2
    4
    2
    1
    4
    1
    1
    4
    2
    3
    2
    4
    2
    4
    2
    2
    2
    1
    2
    4
    1
    1
    1
    2
    4
    3
    1
    2
    1
    1
    2
    2
    4
    1
    1
    1
    4
    3
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_11
  orbit_12
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  (not orbit_45)
  orbit_47
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_61)
  (not orbit_62)
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_67
  (not orbit_69)
  (not orbit_70)
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  (not orbit_89)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    1
    4
    1
    1
    2
    4
    2
    3
    2
    4
    1
    4
    2
    2
    2
    2
    1
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    4
    2
    4
    2
    1
    4
    1
    1
    4
    2
    3
    2
    4
    2
    4
    2
    2
    2
    1
    2
    4
    1
    1
    1
    2
    4
    3
    1
    2
    1
    1
    2
    2
    4
    1
    1
    1
    4
    3
    1
    1
    1
    1)
  orbit_0
  (not orbit_2)
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_11
  orbit_12
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_18)
  orbit_19
  orbit_20
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  orbit_43
  (not orbit_45)
  orbit_47
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_61)
  (not orbit_62)
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_67
  (not orbit_69)
  (not orbit_70)
  (not orbit_72)
  orbit_73
  orbit_74
  orbit_76
  orbit_77
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  (not orbit_89)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_95)
  (not orbit_96)
  (not orbit_97)
  orbit_98
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    2
    1
    6
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    6
    6
    3
    2
    1
    2
    2
    2
    6
    3
    2
    3
    2
    1
    2
    6
    2
    6
    2
    2
    6
    6
    2
    3
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    3
    2
    2
    6
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    6
    6
    2
    6
    3
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  orbit_20
  (not orbit_21)
  orbit_22
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  (not orbit_28)
  orbit_29
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_81
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  orbit_89
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  (not orbit_94)
  orbit_95
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    1
    6
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    6
    6
    3
    2
    1
    2
    2
    2
    6
    3
    2
    3
    2
    1
    2
    6
    2
    6
    2
    2
    6
    6
    2
    3
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    1
    3
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    6
    2
    3
    2
    2
    6
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    6
    6
    2
    6
    3
    2
    3
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  orbit_20
  (not orbit_21)
  orbit_22
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  (not orbit_28)
  orbit_29
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_34
  (not orbit_35)
  orbit_36
  orbit_37
  (not orbit_38)
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  (not orbit_48)
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  (not orbit_77)
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_81
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  orbit_89
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  (not orbit_94)
  orbit_95
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    82
    1
    2
    1
    2
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  (not orbit_28)
  orbit_29
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  orbit_63
  (not orbit_64)
  orbit_65
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    3
    1
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    3
    2
    2
    1
    2
    2
    1
    2
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  (not orbit_3)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  (not orbit_28)
  orbit_29
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  (not orbit_35)
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  orbit_63
  (not orbit_64)
  orbit_65
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  (not orbit_80)
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    2
    2
    6
    1
    6
    3
    6
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    2
    6
    2
    2
    2
    2
    1
    2
    3
    3
    6
    2
    1
    2
    2
    2
    2
    2
    6
    2
    6
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    6
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    3
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  orbit_24
  (not orbit_25)
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  orbit_55
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  orbit_67
  (not orbit_68)
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  orbit_95
  (not orbit_96)
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    2
    2
    6
    1
    6
    3
    6
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    2
    6
    2
    2
    2
    2
    1
    2
    3
    3
    6
    2
    1
    2
    2
    2
    2
    2
    6
    2
    6
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    6
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    3
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  orbit_1
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  (not orbit_13)
  orbit_14
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  orbit_24
  (not orbit_25)
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  orbit_31
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  (not orbit_38)
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  orbit_55
  (not orbit_56)
  orbit_57
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  orbit_67
  (not orbit_68)
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  (not orbit_86)
  orbit_87
  orbit_88
  (not orbit_89)
  (not orbit_90)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  orbit_95
  (not orbit_96)
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    50
    1
    3
    1
    1
    2
    2
    3
    6
    3
    2
    2
    2
    2
    3
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    3
    1
    1
    2
    3
    6
    6
    2
    2
    2
    3
    6
    1
    1
    1
    2
    3
    1
    2
    1
    1
    2
    2
    3
    1
    1
    3
    1
    3
    3
    1)
  orbit_0
  (not orbit_2)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_8
  (not orbit_9)
  orbit_11
  orbit_14
  (not orbit_16)
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_22)
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  (not orbit_47)
  (not orbit_50)
  orbit_52
  orbit_53
  (not orbit_55)
  orbit_56
  (not orbit_58)
  orbit_59
  (not orbit_61)
  (not orbit_63)
  orbit_65
  (not orbit_67)
  orbit_69
  (not orbit_70)
  orbit_72
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  orbit_80
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_87
  orbit_89
  (not orbit_91)
  orbit_93
  (not orbit_95)
  orbit_96
  (not orbit_98)
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    78
    1
    3
    1
    1
    2
    2
    3
    6
    3
    2
    2
    2
    2
    3
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    3
    1
    1
    2
    3
    6
    6
    2
    2
    2
    3
    6
    1
    1
    1
    2
    3
    1
    2
    1
    1
    2
    2
    3
    1
    1
    3
    1
    3
    3
    1)
  orbit_0
  (not orbit_2)
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_8
  (not orbit_9)
  orbit_11
  orbit_14
  (not orbit_16)
  orbit_18
  orbit_19
  (not orbit_20)
  (not orbit_22)
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  (not orbit_47)
  (not orbit_50)
  orbit_52
  orbit_53
  (not orbit_55)
  orbit_56
  (not orbit_58)
  orbit_59
  (not orbit_61)
  (not orbit_63)
  orbit_65
  (not orbit_67)
  orbit_69
  (not orbit_70)
  orbit_72
  (not orbit_74)
  orbit_76
  (not orbit_77)
  orbit_78
  orbit_80
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_87
  orbit_89
  (not orbit_91)
  orbit_93
  (not orbit_95)
  orbit_96
  (not orbit_98)
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    3
    2
    3
    3
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    6
    6
    2
    6
    2
    1
    6
    1
    1
    2
    2
    1
    2
    2
    2
    2
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    3
    2
    2
    1
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  orbit_13
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  orbit_28
  orbit_29
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  orbit_33
  orbit_34
  orbit_35
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_81
  (not orbit_82)
  (not orbit_83)
  orbit_84
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    3
    2
    3
    3
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    6
    6
    2
    6
    2
    1
    6
    1
    1
    2
    2
    1
    2
    2
    2
    2
    6
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    3
    2
    2
    1
    2
    2
    3
    6
    1
    2
    3
    2
    2
    6
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  (not orbit_10)
  orbit_11
  orbit_12
  orbit_13
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  orbit_18
  orbit_19
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  (not orbit_26)
  orbit_27
  orbit_28
  orbit_29
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  orbit_33
  orbit_34
  orbit_35
  (not orbit_36)
  orbit_37
  (not orbit_38)
  (not orbit_39)
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  orbit_44
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_79)
  orbit_80
  orbit_81
  (not orbit_82)
  (not orbit_83)
  orbit_84
  orbit_85
  orbit_86
  (not orbit_87)
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    3
    3
    3
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    3
    6
    3
    6
    3
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    3
    3
    3
    6
    3
    6
    6
    6
    6
    6
    3
    6
    1
    3
    3
    6
    3
    3
    6
    3
    3
    6
    6
    3
    3
    3
    3
    1
    3
    3
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_8)
  (not orbit_9)
  orbit_11
  orbit_14
  orbit_16
  (not orbit_18)
  (not orbit_19)
  orbit_20
  (not orbit_22)
  (not orbit_24)
  orbit_25
  orbit_29
  (not orbit_30)
  (not orbit_31)
  orbit_33
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_42
  orbit_43
  (not orbit_45)
  orbit_47
  orbit_50
  (not orbit_52)
  orbit_53
  orbit_55
  (not orbit_56)
  orbit_58
  orbit_59
  (not orbit_61)
  (not orbit_63)
  (not orbit_65)
  orbit_67
  (not orbit_69)
  (not orbit_70)
  orbit_72
  (not orbit_74)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_80
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  (not orbit_89)
  orbit_91
  orbit_93
  orbit_95
  (not orbit_96)
  (not orbit_98)
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    142
    1
    3
    3
    3
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    3
    6
    3
    6
    3
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    3
    3
    3
    6
    3
    6
    6
    6
    6
    6
    3
    6
    1
    3
    3
    6
    3
    3
    6
    3
    3
    6
    6
    3
    3
    3
    3
    1
    3
    3
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  orbit_6
  (not orbit_8)
  (not orbit_9)
  orbit_11
  orbit_14
  orbit_16
  (not orbit_18)
  (not orbit_19)
  orbit_20
  (not orbit_22)
  (not orbit_24)
  orbit_25
  orbit_29
  (not orbit_30)
  (not orbit_31)
  orbit_33
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_42
  orbit_43
  (not orbit_45)
  orbit_47
  orbit_50
  (not orbit_52)
  orbit_53
  orbit_55
  (not orbit_56)
  orbit_58
  orbit_59
  (not orbit_61)
  (not orbit_63)
  (not orbit_65)
  orbit_67
  (not orbit_69)
  (not orbit_70)
  orbit_72
  (not orbit_74)
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_80
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  (not orbit_89)
  orbit_91
  orbit_93
  orbit_95
  (not orbit_96)
  (not orbit_98)
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    1
    2
    1
    3
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  orbit_6
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  orbit_33
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  orbit_38
  (not orbit_39)
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  orbit_63
  orbit_64
  orbit_65
  (not orbit_66)
  orbit_67
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  (not orbit_88)
  orbit_89
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    110
    1
    2
    1
    2
    1
    3
    2
    2
    2
    1
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  orbit_6
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  orbit_20
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  orbit_33
  (not orbit_34)
  orbit_35
  orbit_36
  orbit_37
  orbit_38
  (not orbit_39)
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  orbit_45
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  orbit_63
  orbit_64
  orbit_65
  (not orbit_66)
  orbit_67
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  (not orbit_77)
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  (not orbit_88)
  orbit_89
  orbit_90
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    50
    1
    3
    3
    3
    2
    2
    1
    2
    3
    6
    6
    2
    2
    1
    1
    2
    3
    6
    1
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    3
    2
    1
    3
    6
    1
    3
    2
    2
    1
    1
    1
    1
    1
    3
    3
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  orbit_14
  orbit_16
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_24
  (not orbit_25)
  orbit_29
  (not orbit_30)
  orbit_31
  orbit_33
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  (not orbit_55)
  orbit_56
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_72)
  (not orbit_74)
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_80)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_98
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    78
    1
    3
    3
    3
    2
    2
    1
    2
    3
    6
    6
    2
    2
    1
    1
    2
    3
    6
    1
    3
    2
    2
    2
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    3
    3
    2
    1
    3
    6
    1
    3
    2
    2
    1
    1
    1
    1
    1
    3
    3
    1)
  orbit_0
  (not orbit_2)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_8
  orbit_9
  (not orbit_11)
  orbit_14
  orbit_16
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_24
  (not orbit_25)
  orbit_29
  (not orbit_30)
  orbit_31
  orbit_33
  orbit_35
  orbit_38
  (not orbit_40)
  (not orbit_42)
  (not orbit_43)
  orbit_45
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  (not orbit_55)
  orbit_56
  (not orbit_58)
  (not orbit_59)
  orbit_61
  orbit_63
  orbit_65
  (not orbit_67)
  orbit_69
  orbit_70
  (not orbit_72)
  (not orbit_74)
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_80)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_98
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    82
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    6
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  orbit_6
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  orbit_20
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  orbit_38
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  orbit_47
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  orbit_80
  (not orbit_81)
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  orbit_88
  orbit_89
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    110
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    2
    2
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    1
    2
    1
    2
    2
    2
    2
    1
    2
    1
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    2
    6
    2
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    2
    1
    2
    2
    1
    2
    1
    2
    1
    2
    2
    2
    2
    2
    1
    2
    1
    1
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  orbit_6
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  (not orbit_19)
  orbit_20
  (not orbit_21)
  (not orbit_22)
  orbit_23
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  orbit_37
  orbit_38
  (not orbit_39)
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  orbit_47
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  orbit_51
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  orbit_69
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  (not orbit_78)
  orbit_79
  orbit_80
  (not orbit_81)
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  orbit_88
  orbit_89
  (not orbit_90)
  (not orbit_91)
  orbit_92
  (not orbit_93)
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    4
    1
    4
    1
    3
    2
    2
    1
    2
    4
    1
    2
    2
    2
    2
    1
    4
    1
    2
    4
    1
    2
    1
    4
    3
    2
    2
    2
    4
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    4
    2
    2
    2
    2
    2
    1
    2
    4
    1
    4
    3
    1
    2
    4
    1
    4
    3
    2
    1
    1
    2
    2
    4
    1
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  orbit_6
  orbit_8
  orbit_9
  orbit_11
  (not orbit_12)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  orbit_20
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_27)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  orbit_33
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_63)
  (not orbit_65)
  orbit_67
  orbit_69
  orbit_70
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_87
  (not orbit_89)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_98
  (not orbit_99)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pble
    94
    1
    4
    1
    4
    1
    3
    2
    2
    1
    2
    4
    1
    2
    2
    2
    2
    1
    4
    1
    2
    4
    1
    2
    1
    4
    3
    2
    2
    2
    4
    2
    1
    4
    2
    2
    2
    2
    1
    1
    1
    4
    2
    1
    4
    2
    2
    2
    2
    2
    1
    2
    4
    1
    4
    3
    1
    2
    4
    1
    4
    3
    2
    1
    1
    2
    2
    4
    1
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  orbit_6
  orbit_8
  orbit_9
  orbit_11
  (not orbit_12)
  (not orbit_14)
  (not orbit_16)
  orbit_18
  orbit_19
  orbit_20
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_27)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  orbit_33
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  (not orbit_47)
  (not orbit_50)
  orbit_52
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  (not orbit_63)
  (not orbit_65)
  orbit_67
  orbit_69
  orbit_70
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  (not orbit_85)
  orbit_87
  (not orbit_89)
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_95)
  orbit_96
  orbit_98
  (not orbit_99)
  (not orbit_100)
  (not orbit_101)
  orbit_102
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    1
    2
    1
    3
    2
    2
    6
    3
    2
    2
    2
    6
    1
    2
    2
    6
    2
    2
    2
    6
    1
    2
    1
    2
    6
    2
    2
    1
    2
    3
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    3
    2
    6
    3
    2
    2
    2
    2
    2
    2
    6
    2
    6
    2
    1
    6
    2
    2
    1
    2
    3
    1
    2
    2
    3
    2
    2
    3
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    6
    3
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  orbit_33
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  orbit_95
  (not orbit_96)
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    142
    1
    2
    1
    2
    1
    3
    2
    2
    6
    3
    2
    2
    2
    6
    1
    2
    2
    6
    2
    2
    2
    6
    1
    2
    1
    2
    6
    2
    2
    1
    2
    3
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    2
    2
    2
    2
    2
    6
    1
    2
    1
    3
    2
    6
    3
    2
    2
    2
    2
    2
    2
    6
    2
    6
    2
    1
    6
    2
    2
    1
    2
    3
    1
    2
    2
    3
    2
    2
    3
    2
    1
    6
    1
    2
    2
    2
    2
    2
    1
    6
    3
    1
    2
    3
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_10)
  (not orbit_11)
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_15)
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  (not orbit_23)
  (not orbit_24)
  (not orbit_25)
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  (not orbit_30)
  orbit_31
  (not orbit_32)
  orbit_33
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  (not orbit_45)
  (not orbit_46)
  (not orbit_47)
  (not orbit_48)
  (not orbit_49)
  (not orbit_50)
  (not orbit_51)
  orbit_52
  (not orbit_53)
  (not orbit_54)
  (not orbit_55)
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_60)
  (not orbit_61)
  (not orbit_62)
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  orbit_95
  (not orbit_96)
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    66
    1
    4
    1
    1
    1
    2
    2
    1
    2
    4
    4
    1
    2
    4
    2
    2
    2
    3
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    4
    2
    4
    2
    3
    4
    1
    1
    4
    2
    1
    4
    2
    2
    4
    2
    2
    2
    3
    4
    2
    1
    4
    1
    1
    2
    4
    1
    1
    2
    1
    1
    2
    2
    3
    4
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_4
  orbit_5
  orbit_6
  orbit_8
  orbit_9
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_22)
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_42
  orbit_43
  (not orbit_45)
  (not orbit_47)
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_67
  orbit_69
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  orbit_89
  (not orbit_91)
  orbit_93
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  orbit_99
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    4
    1
    1
    1
    2
    2
    1
    2
    4
    4
    1
    2
    4
    2
    2
    2
    3
    4
    1
    2
    1
    2
    1
    1
    2
    2
    2
    2
    1
    2
    2
    4
    2
    4
    2
    3
    4
    1
    1
    4
    2
    1
    4
    2
    2
    4
    2
    2
    2
    3
    4
    2
    1
    4
    1
    1
    2
    4
    1
    1
    2
    1
    1
    2
    2
    3
    4
    1
    1
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_4
  orbit_5
  orbit_6
  orbit_8
  orbit_9
  orbit_11
  (not orbit_12)
  orbit_13
  (not orbit_14)
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  (not orbit_22)
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  orbit_42
  orbit_43
  (not orbit_45)
  (not orbit_47)
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  (not orbit_56)
  orbit_57
  (not orbit_58)
  (not orbit_59)
  orbit_60
  (not orbit_61)
  orbit_63
  (not orbit_64)
  orbit_65
  orbit_67
  orbit_69
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  orbit_89
  (not orbit_91)
  orbit_93
  (not orbit_94)
  (not orbit_95)
  (not orbit_96)
  (not orbit_98)
  orbit_99
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    2
    1
    2
    1
    3
    2
    6
    2
    1
    6
    2
    2
    2
    1
    6
    2
    2
    2
    6
    2
    2
    3
    2
    3
    2
    2
    2
    6
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    6
    6
    2
    2
    6
    2
    2
    3
    2
    3
    1
    2
    2
    1
    2
    2
    6
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    6
    2
    3
    2
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    3
    6
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  orbit_33
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  orbit_46
  orbit_47
  (not orbit_48)
  (not orbit_49)
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  (not orbit_54)
  orbit_55
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  orbit_66
  (not orbit_67)
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    142
    1
    2
    1
    2
    1
    3
    2
    6
    2
    1
    6
    2
    2
    2
    1
    6
    2
    2
    2
    6
    2
    2
    3
    2
    3
    2
    2
    2
    6
    1
    2
    1
    2
    3
    2
    2
    2
    2
    2
    6
    2
    2
    2
    1
    2
    2
    6
    6
    2
    2
    6
    2
    2
    3
    2
    3
    1
    2
    2
    1
    2
    2
    6
    2
    2
    2
    6
    2
    2
    6
    3
    2
    2
    2
    1
    2
    3
    1
    2
    2
    1
    6
    2
    3
    2
    3
    2
    1
    2
    2
    2
    2
    2
    3
    2
    1
    3
    6
    1
    2
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  (not orbit_3)
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  (not orbit_8)
  (not orbit_9)
  orbit_10
  (not orbit_11)
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_26)
  (not orbit_27)
  orbit_28
  (not orbit_29)
  (not orbit_30)
  (not orbit_31)
  (not orbit_32)
  orbit_33
  orbit_34
  (not orbit_35)
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  orbit_39
  (not orbit_40)
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  (not orbit_44)
  (not orbit_45)
  orbit_46
  orbit_47
  (not orbit_48)
  (not orbit_49)
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  (not orbit_54)
  orbit_55
  (not orbit_56)
  (not orbit_57)
  (not orbit_58)
  (not orbit_59)
  (not orbit_60)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  orbit_66
  (not orbit_67)
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  (not orbit_72)
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  (not orbit_87)
  orbit_88
  (not orbit_89)
  (not orbit_90)
  (not orbit_91)
  (not orbit_92)
  orbit_93
  (not orbit_94)
  (not orbit_95)
  orbit_96
  orbit_97
  (not orbit_98)
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    114
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    2
    2
    6
    1
    6
    3
    6
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    2
    6
    2
    2
    2
    2
    1
    2
    3
    3
    6
    2
    1
    2
    2
    2
    2
    2
    6
    2
    6
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    6
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    3
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  (not orbit_47)
  orbit_48
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  orbit_55
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  orbit_67
  orbit_68
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  orbit_95
  (not orbit_96)
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    3
    2
    1
    1
    2
    2
    2
    1
    6
    2
    6
    2
    3
    2
    2
    2
    2
    2
    2
    6
    1
    6
    3
    6
    2
    2
    2
    1
    2
    3
    2
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    2
    6
    2
    2
    2
    2
    1
    2
    3
    3
    6
    2
    1
    2
    2
    2
    2
    2
    6
    2
    6
    6
    2
    1
    2
    2
    2
    1
    2
    1
    1
    2
    6
    1
    6
    2
    1
    2
    3
    2
    1
    2
    2
    2
    2
    2
    1
    2
    3
    3
    2
    1
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  (not orbit_9)
  orbit_10
  orbit_11
  (not orbit_12)
  orbit_13
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_26)
  orbit_27
  orbit_28
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_32)
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  (not orbit_47)
  orbit_48
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  orbit_53
  orbit_54
  orbit_55
  (not orbit_56)
  (not orbit_57)
  orbit_58
  (not orbit_59)
  (not orbit_60)
  orbit_61
  orbit_62
  (not orbit_63)
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  orbit_67
  orbit_68
  (not orbit_69)
  orbit_70
  orbit_71
  (not orbit_72)
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_86
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  (not orbit_93)
  (not orbit_94)
  orbit_95
  (not orbit_96)
  (not orbit_97)
  orbit_98
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    4
    1
    1
    1
    2
    4
    2
    1
    2
    1
    4
    2
    2
    2
    2
    1
    1
    2
    4
    1
    2
    3
    4
    1
    2
    2
    2
    2
    3
    4
    2
    2
    4
    2
    4
    2
    1
    4
    1
    3
    2
    1
    4
    2
    4
    2
    4
    2
    2
    2
    1
    2
    1
    4
    1
    1
    2
    1
    4
    1
    2
    1
    1
    2
    2
    1
    3
    1
    4
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_4
  orbit_5
  orbit_6
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_24
  orbit_25
  (not orbit_27)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_42)
  (not orbit_43)
  orbit_44
  orbit_45
  orbit_47
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  orbit_72
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  orbit_80
  (not orbit_82)
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_95
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    94
    1
    4
    1
    1
    1
    2
    4
    2
    1
    2
    1
    4
    2
    2
    2
    2
    1
    1
    2
    4
    1
    2
    3
    4
    1
    2
    2
    2
    2
    3
    4
    2
    2
    4
    2
    4
    2
    1
    4
    1
    3
    2
    1
    4
    2
    4
    2
    4
    2
    2
    2
    1
    2
    1
    4
    1
    1
    2
    1
    4
    1
    2
    1
    1
    2
    2
    1
    3
    1
    4
    1
    4
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_4
  orbit_5
  orbit_6
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_11)
  (not orbit_14)
  orbit_15
  (not orbit_16)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_22
  orbit_24
  orbit_25
  (not orbit_27)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_42)
  (not orbit_43)
  orbit_44
  orbit_45
  orbit_47
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  orbit_53
  (not orbit_54)
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  (not orbit_65)
  (not orbit_67)
  (not orbit_69)
  (not orbit_70)
  orbit_72
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  orbit_80
  (not orbit_82)
  (not orbit_83)
  orbit_84
  orbit_85
  (not orbit_87)
  orbit_89
  (not orbit_91)
  (not orbit_93)
  orbit_95
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  (not orbit_100)
  orbit_101
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    2
    3
    2
    1
    1
    2
    2
    2
    3
    2
    6
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    6
    6
    6
    1
    2
    1
    6
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    6
    2
    6
    2
    6
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    1
    2
    1
    1
    2
    2
    3
    2
    6
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    3
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  orbit_9
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  orbit_22
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  (not orbit_60)
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    142
    1
    2
    3
    2
    1
    1
    2
    2
    2
    3
    2
    6
    2
    2
    3
    2
    2
    2
    2
    2
    2
    2
    3
    2
    1
    2
    6
    6
    6
    1
    2
    1
    6
    1
    2
    2
    6
    2
    2
    2
    2
    2
    2
    1
    6
    2
    6
    2
    6
    2
    2
    2
    2
    3
    2
    1
    1
    2
    2
    3
    2
    6
    2
    6
    2
    2
    2
    2
    2
    2
    3
    2
    6
    2
    1
    2
    1
    1
    2
    2
    3
    2
    6
    1
    2
    1
    6
    1
    2
    2
    2
    2
    2
    3
    2
    1
    1
    2
    3
    2
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  (not orbit_4)
  orbit_5
  (not orbit_6)
  orbit_7
  orbit_8
  orbit_9
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  (not orbit_18)
  orbit_19
  (not orbit_20)
  orbit_21
  orbit_22
  (not orbit_23)
  (not orbit_24)
  orbit_25
  orbit_26
  (not orbit_27)
  (not orbit_28)
  (not orbit_29)
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  orbit_34
  orbit_35
  (not orbit_36)
  (not orbit_37)
  (not orbit_38)
  orbit_39
  orbit_40
  (not orbit_41)
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  orbit_50
  (not orbit_51)
  (not orbit_52)
  (not orbit_53)
  orbit_54
  (not orbit_55)
  orbit_56
  orbit_57
  orbit_58
  orbit_59
  (not orbit_60)
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_64)
  orbit_65
  (not orbit_66)
  (not orbit_67)
  (not orbit_68)
  (not orbit_69)
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  (not orbit_76)
  orbit_77
  orbit_78
  (not orbit_79)
  (not orbit_80)
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  (not orbit_89)
  orbit_90
  orbit_91
  orbit_92
  orbit_93
  (not orbit_94)
  (not orbit_95)
  orbit_96
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pbge
    66
    1
    4
    3
    4
    1
    1
    2
    4
    2
    1
    2
    4
    3
    4
    2
    4
    2
    2
    2
    1
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    4
    2
    4
    2
    2
    2
    2
    1
    4
    2
    4
    1
    4
    1
    1
    2
    1
    1
    2
    1
    1
    2
    2
    4
    1
    4
    1
    1
    4
    1
    4
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  orbit_6
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_11)
  orbit_13
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_22
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_45
  orbit_47
  orbit_50
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  orbit_63
  orbit_65
  (not orbit_67)
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_80)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_87
  (not orbit_89)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    94
    1
    4
    3
    4
    1
    1
    2
    4
    2
    1
    2
    4
    3
    4
    2
    4
    2
    2
    2
    1
    1
    2
    1
    2
    1
    1
    2
    2
    2
    4
    2
    1
    2
    2
    2
    2
    1
    1
    1
    2
    1
    4
    2
    4
    2
    2
    2
    2
    1
    4
    2
    4
    1
    4
    1
    1
    2
    1
    1
    2
    1
    1
    2
    2
    4
    1
    4
    1
    1
    4
    1
    4
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  orbit_6
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_11)
  orbit_13
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_22
  orbit_24
  (not orbit_25)
  (not orbit_29)
  orbit_30
  orbit_31
  (not orbit_33)
  (not orbit_35)
  (not orbit_38)
  orbit_40
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_45
  orbit_47
  orbit_50
  (not orbit_52)
  (not orbit_53)
  (not orbit_55)
  orbit_56
  orbit_58
  (not orbit_59)
  orbit_60
  orbit_61
  (not orbit_62)
  orbit_63
  orbit_65
  (not orbit_67)
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_80)
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_87
  (not orbit_89)
  orbit_91
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  (not orbit_100)
  orbit_101
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    242
    1
    6
    3
    6
    3
    3
    6
    6
    6
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    3
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    1
    6
    3
    3
    6
    6
    3
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    3
    6
    3
    3
    6
    3
    6
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  orbit_6
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  orbit_20
  (not orbit_21)
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  orbit_29
  orbit_30
  orbit_31
  (not orbit_32)
  orbit_33
  (not orbit_34)
  orbit_35
  (not orbit_36)
  (not orbit_37)
  orbit_38
  (not orbit_39)
  orbit_40
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  orbit_53
  (not orbit_54)
  orbit_55
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_60)
  orbit_61
  (not orbit_62)
  orbit_63
  (not orbit_64)
  orbit_65
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  orbit_89
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  (not orbit_94)
  orbit_95
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pble
    270
    1
    6
    3
    6
    3
    3
    6
    6
    6
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    3
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    1
    6
    3
    3
    6
    6
    3
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    3
    6
    3
    3
    6
    3
    6
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  orbit_6
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  orbit_14
  (not orbit_15)
  orbit_16
  (not orbit_17)
  orbit_18
  orbit_19
  orbit_20
  (not orbit_21)
  orbit_22
  (not orbit_23)
  orbit_24
  orbit_25
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  orbit_29
  orbit_30
  orbit_31
  (not orbit_32)
  orbit_33
  (not orbit_34)
  orbit_35
  (not orbit_36)
  (not orbit_37)
  orbit_38
  (not orbit_39)
  orbit_40
  (not orbit_41)
  orbit_42
  orbit_43
  (not orbit_44)
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  (not orbit_49)
  orbit_50
  (not orbit_51)
  orbit_52
  orbit_53
  (not orbit_54)
  orbit_55
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_60)
  orbit_61
  (not orbit_62)
  orbit_63
  (not orbit_64)
  orbit_65
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  orbit_70
  (not orbit_71)
  orbit_72
  (not orbit_73)
  orbit_74
  (not orbit_75)
  orbit_76
  orbit_77
  orbit_78
  (not orbit_79)
  orbit_80
  (not orbit_81)
  (not orbit_82)
  orbit_83
  orbit_84
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  orbit_89
  (not orbit_90)
  orbit_91
  (not orbit_92)
  orbit_93
  (not orbit_94)
  orbit_95
  orbit_96
  (not orbit_97)
  orbit_98
  (not orbit_99)
  orbit_100
  orbit_101
  orbit_102
  orbit_103))
(assert ((_ pbge
    114
    1
    6
    1
    2
    3
    1
    6
    2
    2
    3
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    6
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    6
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    3
    6
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    6
    1
    3
    6
    2
    3
    6
    2
    1
    2
    3
    6
    3
    2
    2
    6
    6
    2
    1
    2
    1
    3
    2
    3
    6
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  orbit_6
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  orbit_24
  orbit_25
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  orbit_29
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  (not orbit_37)
  orbit_38
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  orbit_55
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_60)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  (not orbit_89)
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pble
    142
    1
    6
    1
    2
    3
    1
    6
    2
    2
    3
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    6
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    6
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    3
    6
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    6
    1
    3
    6
    2
    3
    6
    2
    1
    2
    3
    6
    3
    2
    2
    6
    6
    2
    1
    2
    1
    3
    2
    3
    6
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  orbit_2
  (not orbit_3)
  orbit_4
  orbit_5
  orbit_6
  (not orbit_7)
  orbit_8
  orbit_9
  (not orbit_10)
  orbit_11
  (not orbit_12)
  (not orbit_13)
  (not orbit_14)
  orbit_15
  orbit_16
  orbit_17
  (not orbit_18)
  orbit_19
  (not orbit_20)
  (not orbit_21)
  (not orbit_22)
  orbit_23
  orbit_24
  orbit_25
  (not orbit_26)
  (not orbit_27)
  (not orbit_28)
  orbit_29
  orbit_30
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  orbit_35
  (not orbit_36)
  (not orbit_37)
  orbit_38
  (not orbit_39)
  orbit_40
  orbit_41
  (not orbit_42)
  orbit_43
  (not orbit_44)
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  (not orbit_49)
  orbit_50
  orbit_51
  (not orbit_52)
  orbit_53
  (not orbit_54)
  orbit_55
  orbit_56
  (not orbit_57)
  orbit_58
  orbit_59
  (not orbit_60)
  orbit_61
  (not orbit_62)
  (not orbit_63)
  orbit_64
  orbit_65
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  orbit_70
  (not orbit_71)
  (not orbit_72)
  orbit_73
  (not orbit_74)
  orbit_75
  (not orbit_76)
  (not orbit_77)
  (not orbit_78)
  orbit_79
  (not orbit_80)
  orbit_81
  orbit_82
  orbit_83
  (not orbit_84)
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  (not orbit_89)
  orbit_90
  (not orbit_91)
  (not orbit_92)
  (not orbit_93)
  orbit_94
  (not orbit_95)
  (not orbit_96)
  orbit_97
  (not orbit_98)
  orbit_99
  orbit_100
  orbit_101
  (not orbit_102)
  (not orbit_103)))
(assert ((_ pbge
    114
    1
    6
    1
    2
    3
    1
    6
    2
    2
    3
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    6
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    6
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    3
    6
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    6
    1
    3
    6
    2
    3
    6
    2
    1
    2
    3
    6
    3
    2
    2
    6
    6
    2
    1
    2
    1
    3
    2
    3
    6
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  orbit_6
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_26)
  orbit_27
  orbit_28
  orbit_29
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  (not orbit_37)
  orbit_38
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  orbit_55
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  (not orbit_60)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pble
    142
    1
    6
    1
    2
    3
    1
    6
    2
    2
    3
    6
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    2
    6
    2
    2
    3
    2
    1
    2
    1
    2
    2
    2
    6
    6
    2
    2
    2
    2
    1
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    3
    1
    2
    2
    3
    6
    2
    2
    2
    2
    2
    2
    2
    2
    2
    1
    2
    2
    2
    1
    6
    1
    3
    6
    2
    3
    6
    2
    1
    2
    3
    6
    3
    2
    2
    6
    6
    2
    1
    2
    1
    3
    2
    3
    6
    1
    1
    1
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  orbit_6
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  (not orbit_14)
  orbit_15
  (not orbit_16)
  orbit_17
  (not orbit_18)
  (not orbit_19)
  (not orbit_20)
  orbit_21
  (not orbit_22)
  orbit_23
  orbit_24
  (not orbit_25)
  (not orbit_26)
  orbit_27
  orbit_28
  orbit_29
  (not orbit_30)
  (not orbit_31)
  orbit_32
  (not orbit_33)
  (not orbit_34)
  (not orbit_35)
  orbit_36
  (not orbit_37)
  orbit_38
  orbit_39
  (not orbit_40)
  orbit_41
  (not orbit_42)
  (not orbit_43)
  orbit_44
  (not orbit_45)
  orbit_46
  (not orbit_47)
  orbit_48
  orbit_49
  (not orbit_50)
  orbit_51
  (not orbit_52)
  (not orbit_53)
  orbit_54
  orbit_55
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  (not orbit_60)
  (not orbit_61)
  orbit_62
  (not orbit_63)
  orbit_64
  (not orbit_65)
  orbit_66
  (not orbit_67)
  orbit_68
  (not orbit_69)
  (not orbit_70)
  orbit_71
  (not orbit_72)
  orbit_73
  orbit_74
  (not orbit_75)
  (not orbit_76)
  orbit_77
  orbit_78
  orbit_79
  orbit_80
  (not orbit_81)
  orbit_82
  (not orbit_83)
  (not orbit_84)
  orbit_85
  (not orbit_86)
  orbit_87
  (not orbit_88)
  (not orbit_89)
  (not orbit_90)
  orbit_91
  orbit_92
  (not orbit_93)
  orbit_94
  (not orbit_95)
  orbit_96
  orbit_97
  orbit_98
  (not orbit_99)
  orbit_100
  (not orbit_101)
  (not orbit_102)
  orbit_103))
(assert ((_ pbge
    242
    1
    6
    3
    6
    3
    3
    6
    6
    6
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    3
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    1
    6
    3
    3
    6
    6
    3
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    3
    6
    3
    3
    6
    3
    6
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  orbit_6
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_21
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_26)
  orbit_27
  orbit_28
  orbit_29
  (not orbit_30)
  orbit_31
  (not orbit_32)
  orbit_33
  (not orbit_34)
  (not orbit_35)
  orbit_36
  (not orbit_37)
  orbit_38
  orbit_39
  (not orbit_40)
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  (not orbit_53)
  orbit_54
  orbit_55
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  (not orbit_60)
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  orbit_89
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  (not orbit_94)
  orbit_95
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert ((_ pble
    270
    1
    6
    3
    6
    3
    3
    6
    6
    6
    3
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    6
    6
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    3
    3
    6
    6
    3
    6
    6
    6
    6
    6
    6
    6
    6
    6
    6
    3
    6
    6
    6
    1
    6
    3
    3
    6
    6
    3
    6
    6
    3
    6
    3
    6
    3
    2
    6
    6
    6
    6
    3
    6
    3
    3
    6
    3
    6
    1
    3
    3
    1)
  orbit_0
  (not orbit_1)
  (not orbit_2)
  orbit_3
  orbit_4
  (not orbit_5)
  orbit_6
  orbit_7
  (not orbit_8)
  orbit_9
  (not orbit_10)
  (not orbit_11)
  orbit_12
  orbit_13
  orbit_14
  (not orbit_15)
  (not orbit_16)
  (not orbit_17)
  orbit_18
  (not orbit_19)
  orbit_20
  orbit_21
  orbit_22
  (not orbit_23)
  orbit_24
  (not orbit_25)
  (not orbit_26)
  orbit_27
  orbit_28
  orbit_29
  (not orbit_30)
  orbit_31
  (not orbit_32)
  orbit_33
  (not orbit_34)
  (not orbit_35)
  orbit_36
  (not orbit_37)
  orbit_38
  orbit_39
  (not orbit_40)
  (not orbit_41)
  orbit_42
  (not orbit_43)
  orbit_44
  orbit_45
  (not orbit_46)
  orbit_47
  (not orbit_48)
  orbit_49
  (not orbit_50)
  (not orbit_51)
  orbit_52
  (not orbit_53)
  orbit_54
  orbit_55
  (not orbit_56)
  orbit_57
  (not orbit_58)
  orbit_59
  (not orbit_60)
  (not orbit_61)
  orbit_62
  orbit_63
  (not orbit_64)
  (not orbit_65)
  (not orbit_66)
  orbit_67
  (not orbit_68)
  orbit_69
  (not orbit_70)
  orbit_71
  orbit_72
  (not orbit_73)
  (not orbit_74)
  orbit_75
  orbit_76
  (not orbit_77)
  (not orbit_78)
  (not orbit_79)
  (not orbit_80)
  orbit_81
  (not orbit_82)
  (not orbit_83)
  orbit_84
  (not orbit_85)
  orbit_86
  (not orbit_87)
  orbit_88
  orbit_89
  orbit_90
  (not orbit_91)
  orbit_92
  orbit_93
  (not orbit_94)
  orbit_95
  (not orbit_96)
  (not orbit_97)
  (not orbit_98)
  orbit_99
  orbit_100
  (not orbit_101)
  orbit_102
  (not orbit_103)))
(assert (let ((a!1 (xor false
                orbit_1
                orbit_3
                orbit_4
                orbit_5
                orbit_7
                orbit_9
                orbit_10
                orbit_12
                orbit_13
                orbit_15
                orbit_17
                orbit_21
                orbit_22
                orbit_23
                orbit_24
                orbit_26
                orbit_27
                orbit_28
                orbit_31
                orbit_32
                orbit_34
                orbit_36
                orbit_37
                orbit_39
                orbit_41
                orbit_43
                orbit_44
                orbit_46
                orbit_48
                orbit_49
                orbit_51
                orbit_53
                orbit_54
                orbit_57
                orbit_60
                orbit_62
                orbit_64
                orbit_66
                orbit_68
                orbit_71
                orbit_73
                orbit_75
                orbit_76
                orbit_77
                orbit_79
                orbit_80
                orbit_81
                orbit_82
                orbit_85
                orbit_86
                orbit_88
                orbit_90
                orbit_92
                orbit_94
                orbit_97
                orbit_99
                orbit_100
                orbit_101
                orbit_102
                orbit_103))
      (a!2 (xor false
                orbit_2
                orbit_5
                orbit_43
                orbit_53
                orbit_56
                orbit_70
                orbit_74
                orbit_77
                orbit_80
                orbit_83
                orbit_85
                orbit_87
                orbit_96
                orbit_98
                orbit_101
                orbit_103)))
  (or a!1 a!2 a!1 a!1 a!2 a!1 a!1 a!2 a!1)))
(assert (not orbit_0))
